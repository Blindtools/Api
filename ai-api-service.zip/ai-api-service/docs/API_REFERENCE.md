# API Reference Guide

## Overview

The Advanced Open-Source AI API Service provides comprehensive endpoints for OCR, image analysis, and real-time text processing. All endpoints return JSON responses and support standard HTTP status codes.

## Base Information

- **Base URL**: `http://localhost:3000` (development) or your deployed URL
- **Content-Type**: `application/json` for JSON requests, `multipart/form-data` for file uploads
- **Rate Limiting**: 100 requests per 15 minutes per IP (configurable)

## Response Format

All API responses follow this consistent structure:

```json
{
  "success": boolean,
  "data": object | array,
  "metadata": {
    "timestamp": "ISO 8601 timestamp",
    "requestId": "unique identifier",
    "processingTime": "time in milliseconds",
    "additionalInfo": "varies by endpoint"
  }
}
```

## Error Handling

Error responses include detailed information:

```json
{
  "error": true,
  "message": "Human-readable error message",
  "statusCode": 400,
  "timestamp": "2025-08-17T07:21:27.136Z",
  "path": "/api/endpoint",
  "method": "POST",
  "details": "Additional error details when available"
}
```

## Health Check Endpoints

### GET /api/health

Basic health check endpoint.

**Response:**
```json
{
  "success": true,
  "data": {
    "status": "healthy",
    "timestamp": "2025-08-17T07:21:27.136Z",
    "uptime": 15.707021403,
    "version": "1.0.0",
    "environment": "development"
  }
}
```

### GET /api/health/detailed

Comprehensive system health information.

**Response includes:**
- System information (OS, memory, CPU)
- Process information (PID, memory usage)
- Directory status
- Service availability
- Configuration summary

### GET /api/health/services

Status of individual AI services.

**Response:**
```json
{
  "success": true,
  "data": {
    "services": {
      "ocr": {
        "name": "OCR Service",
        "status": "healthy",
        "engines": {
          "tesseract": "available",
          "easyocr": "checking",
          "paddleocr": "checking"
        }
      }
    }
  }
}
```

## OCR Endpoints

### POST /api/ocr/image

Extract text from uploaded images using OCR.

**Parameters:**
- `image` (file, required): Image file (JPEG, PNG, WebP, BMP, TIFF)
- `engine` (string, optional): OCR engine - `tesseract`, `easyocr`, `paddleocr`
- `languages` (string, optional): Comma-separated language codes (e.g., "en,es,fr")
- `confidence` (float, optional): Minimum confidence threshold (0.0-1.0)

**Example Request:**
```bash
curl -X POST http://localhost:3000/api/ocr/image \
  -F "image=@document.jpg" \
  -F "engine=tesseract" \
  -F "languages=en,es" \
  -F "confidence=0.7"
```

**Response:**
```json
{
  "success": true,
  "data": {
    "engine": "tesseract",
    "text": "Extracted text content from the image",
    "confidence": 0.95,
    "boundingBoxes": [
      {
        "text": "word",
        "confidence": 0.98,
        "bbox": {
          "x": 100,
          "y": 50,
          "width": 80,
          "height": 20
        }
      }
    ],
    "languages": ["en", "es"],
    "processingTime": 1250,
    "metadata": {
      "imageSize": {
        "width": 1920,
        "height": 1080,
        "format": "JPEG"
      }
    }
  }
}
```

### POST /api/ocr/pdf

Extract text from PDF documents.

**Parameters:**
- `pdf` (file, required): PDF file to process
- `engine` (string, optional): OCR engine for scanned PDFs
- `languages` (string, optional): Language codes for OCR
- `pageRange` (string, optional): Page range (e.g., "1-5" or "1,3,5")
- `ocrMode` (string, optional): Processing mode - `auto`, `text`, `ocr`

**Example Request:**
```bash
curl -X POST http://localhost:3000/api/ocr/pdf \
  -F "pdf=@document.pdf" \
  -F "ocrMode=auto" \
  -F "pageRange=1-3"
```

**Response:**
```json
{
  "success": true,
  "data": {
    "engine": "direct",
    "text": "Full extracted text from PDF",
    "pages": [
      {
        "page": 1,
        "text": "Page 1 content",
        "char_count": 1250,
        "word_count": 200
      }
    ],
    "processingTime": 2100,
    "method": "direct_text_extraction"
  }
}
```

### POST /api/ocr/batch

Process multiple files in batch.

**Parameters:**
- `files` (array of files, required): Up to 10 files
- `engine` (string, optional): OCR engine to use
- `languages` (string, optional): Language codes
- `confidence` (float, optional): Confidence threshold

**Response:**
```json
{
  "success": true,
  "data": {
    "results": [
      {
        "filename": "doc1.jpg",
        "success": true,
        "result": { /* OCR result */ }
      }
    ],
    "errors": [],
    "summary": {
      "total": 3,
      "successful": 3,
      "failed": 0
    }
  }
}
```

### GET /api/ocr/engines

Get available OCR engines and their capabilities.

**Response:**
```json
{
  "success": true,
  "data": {
    "engines": [
      {
        "name": "tesseract",
        "description": "Google Tesseract OCR Engine",
        "available": true,
        "languages": ["eng", "spa", "fra", "deu"],
        "features": ["Multi-language", "Confidence scores", "Bounding boxes"]
      }
    ],
    "default": "tesseract",
    "summary": {
      "total": 3,
      "available": 2
    }
  }
}
```

### GET /api/ocr/languages

Get supported languages for each OCR engine.

## Vision Endpoints

### POST /api/vision/describe

Generate detailed descriptions of images.

**Parameters:**
- `image` (file, required): Image file to analyze
- `model` (string, optional): Vision model - `blip`, `clip`, `local_llm`
- `detail` (string, optional): Detail level - `low`, `medium`, `high`
- `maxLength` (integer, optional): Maximum description length (50-500)
- `temperature` (float, optional): Generation temperature (0.0-2.0)

**Example Request:**
```bash
curl -X POST http://localhost:3000/api/vision/describe \
  -F "image=@photo.jpg" \
  -F "model=blip" \
  -F "detail=high" \
  -F "maxLength=200"
```

**Response:**
```json
{
  "success": true,
  "data": {
    "model": "blip",
    "description": "A detailed description of the image content, including objects, scenes, and visual elements present in the photograph.",
    "confidence": 0.85,
    "details": {
      "dimensions": "1920x1080",
      "orientation": "landscape",
      "color_tone": "vibrant",
      "size_category": "large"
    },
    "processingTime": 1800,
    "metadata": {
      "imageSize": {
        "width": 1920,
        "height": 1080,
        "format": "JPEG",
        "aspectRatio": 1.78
      }
    }
  }
}
```

### POST /api/vision/analyze

Perform comprehensive image analysis.

**Parameters:**
- `image` (file, required): Image file to analyze
- `includeObjects` (boolean, optional): Include object detection
- `includeScenes` (boolean, optional): Include scene analysis
- `includeColors` (boolean, optional): Include color analysis
- `includeComposition` (boolean, optional): Include composition analysis
- `confidence` (float, optional): Detection confidence threshold

**Response:**
```json
{
  "success": true,
  "data": {
    "success": true,
    "analysis_type": "comprehensive",
    "colors": {
      "dominant_colors": [
        {
          "color": "blue",
          "rgb": [65, 105, 225],
          "percentage": 35.2,
          "saturation": 0.76,
          "brightness": 0.88
        }
      ],
      "color_palette": "vibrant"
    },
    "composition": {
      "aspect_ratio": 1.78,
      "composition_type": "landscape",
      "orientation": "landscape",
      "rule_of_thirds": {
        "follows_rule": true,
        "grid_sections": 9
      }
    },
    "objects": {
      "objects": [
        {
          "type": "complex_scene",
          "confidence": 0.7,
          "description": "Scene with multiple elements"
        }
      ],
      "object_count": 1
    },
    "scene": {
      "scene_type": "landscape",
      "environment": "outdoor_landscape",
      "lighting": "bright",
      "setting": "photograph"
    },
    "summary": "A landscape image with landscape orientation featuring a vibrant color palette with bright lighting"
  }
}
```

### POST /api/vision/caption

Generate captions for images.

**Parameters:**
- `image` (file, required): Image file
- `style` (string, optional): Caption style - `descriptive`, `creative`, `technical`
- `length` (string, optional): Caption length - `short`, `medium`, `long`
- `count` (integer, optional): Number of captions to generate (1-5)

**Response:**
```json
{
  "success": true,
  "data": {
    "captions": [
      "A beautiful landscape photograph showing mountains and sky",
      "Scenic mountain view with dramatic lighting and composition"
    ],
    "style": "descriptive",
    "length": "medium",
    "processingTime": 1200
  }
}
```

### POST /api/vision/question

Answer questions about images using Visual Q&A.

**Parameters:**
- `image` (file, required): Image file
- `question` (string, required): Question about the image (5-200 characters)
- `model` (string, optional): Model to use - `blip`, `local_llm`
- `confidence` (float, optional): Answer confidence threshold

**Example Request:**
```bash
curl -X POST http://localhost:3000/api/vision/question \
  -F "image=@photo.jpg" \
  -F "question=What colors are prominent in this image?" \
  -F "model=blip"
```

**Response:**
```json
{
  "success": true,
  "data": {
    "question": "What colors are prominent in this image?",
    "answer": "The image prominently features blue and green colors, with blue dominating the sky area and green visible in the landscape elements.",
    "confidence": 0.82,
    "model": "blip",
    "processingTime": 1500
  }
}
```

### POST /api/vision/batch

Process multiple images in batch.

**Parameters:**
- `images` (array of files, required): Up to 5 image files
- `operation` (string, required): Operation type - `describe`, `analyze`, `caption`
- `model` (string, optional): Vision model to use
- `detail` (string, optional): Detail level for descriptions

### GET /api/vision/models

Get available vision models and their capabilities.

**Response:**
```json
{
  "success": true,
  "data": {
    "models": [
      {
        "id": "blip",
        "name": "BLIP",
        "description": "Bootstrapped Language-Image Pre-training",
        "capabilities": ["image_captioning", "visual_question_answering"],
        "sizes": ["base", "large"],
        "available": true
      }
    ],
    "summary": {
      "total": 3,
      "available": 1
    }
  }
}
```

## Real-time Processing Endpoints

### POST /api/realtime/process

Process data in real-time with various operations.

**Parameters:**
- `data` (string or object, required): Data to process
- `operation` (string, optional): Operation type - `text_analysis`, `data_processing`, `content_generation`
- `options` (object, optional): Additional processing options

**Example Request:**
```bash
curl -X POST http://localhost:3000/api/realtime/process \
  -H "Content-Type: application/json" \
  -d '{
    "data": "This is sample text for analysis",
    "operation": "text_analysis",
    "options": {
      "includeSentiment": true,
      "includeEntities": true
    }
  }'
```

### POST /api/realtime/text/analyze

Analyze text for sentiment, entities, and keywords.

**Parameters:**
- `text` (string, required): Text content to analyze (1-10,000 characters)
- `includeEntities` (boolean, optional): Extract named entities
- `includeSentiment` (boolean, optional): Perform sentiment analysis
- `includeKeywords` (boolean, optional): Extract keywords
- `language` (string, optional): Text language code

**Response:**
```json
{
  "success": true,
  "data": {
    "operation": "text_analysis",
    "result": {
      "success": true,
      "analysis_type": "comprehensive_text_analysis",
      "language": {
        "detected": "en",
        "confidence": 0.8
      },
      "sentiment": {
        "sentiment": "positive",
        "confidence": 0.85,
        "positive_score": 0.2,
        "negative_score": 0.0,
        "positive_words_found": 2,
        "negative_words_found": 0
      },
      "entities": {
        "emails": [],
        "urls": [],
        "phone_numbers": [],
        "dates": [],
        "numbers": [],
        "capitalized_words": ["API", "Service"]
      },
      "keywords": [
        {
          "word": "amazing",
          "frequency": 1,
          "score": 0.14
        }
      ],
      "structure": {
        "sentence_count": 2,
        "word_count": 14,
        "paragraph_count": 1,
        "avg_words_per_sentence": 7,
        "readability_score": 86
      }
    },
    "processingTime": 29
  }
}
```

### POST /api/realtime/text/summarize

Summarize text content.

**Parameters:**
- `text` (string, required): Text to summarize (100-10,000 characters)
- `maxSentences` (integer, optional): Maximum sentences in summary (1-10)
- `style` (string, optional): Summarization style - `extractive`, `abstractive`

**Response:**
```json
{
  "success": true,
  "data": {
    "operation": "summarization",
    "result": {
      "summary": "This is the summarized version of the input text, containing the most important information.",
      "originalLength": 1500,
      "summaryLength": 120,
      "compressionRatio": 0.08,
      "method": "extractive"
    },
    "processingTime": 450
  }
}
```

### POST /api/realtime/text/translate

Translate text between languages.

**Parameters:**
- `text` (string, required): Text to translate (1-5,000 characters)
- `targetLanguage` (string, required): Target language code
- `sourceLanguage` (string, optional): Source language code (auto-detect if not provided)

**Response:**
```json
{
  "success": true,
  "data": {
    "operation": "translation",
    "result": {
      "translatedText": "[Translated to es] This is an amazing AI service!",
      "sourceLanguage": "en",
      "targetLanguage": "es",
      "confidence": 0.8,
      "method": "mock_translation"
    },
    "processingTime": 200
  }
}
```

### POST /api/realtime/data/analyze

Analyze structured data for patterns and insights.

**Parameters:**
- `data` (object or array, required): Structured data to analyze
- `includeStatistics` (boolean, optional): Include statistical analysis
- `includePatterns` (boolean, optional): Include pattern detection
- `includeAnomalies` (boolean, optional): Include anomaly detection

## Stream Processing Endpoints

### POST /api/realtime/stream/start

Start a real-time processing stream.

**Parameters:**
- `operation` (string, optional): Stream operation type
- `batchSize` (integer, optional): Items per batch (1-100)
- `interval` (integer, optional): Processing interval in ms (100-10,000)
- `timeout` (integer, optional): Stream timeout in ms (1,000-300,000)

**Response:**
```json
{
  "success": true,
  "data": {
    "streamId": "uuid-generated-id",
    "status": "started",
    "operation": "stream_processing",
    "startTime": 1692259287136
  }
}
```

### POST /api/realtime/stream/:streamId/add

Add data to an active processing stream.

**Parameters:**
- `data` (any, required): Data to add to the stream

### POST /api/realtime/stream/:streamId/stop

Stop a processing stream.

**Response:**
```json
{
  "success": true,
  "data": {
    "streamId": "uuid-generated-id",
    "status": "stopped",
    "duration": 45000,
    "processedCount": 150,
    "finalBufferSize": 5
  }
}
```

### GET /api/realtime/stream/:streamId/status

Get the status of a specific stream.

### GET /api/realtime/streams

Get all active streams.

**Response:**
```json
{
  "success": true,
  "data": {
    "streams": [
      {
        "streamId": "uuid-1",
        "status": "active",
        "operation": "text_analysis",
        "startTime": 1692259287136,
        "duration": 30000,
        "processedCount": 75,
        "bufferSize": 10
      }
    ],
    "totalActive": 1,
    "totalStreams": 1
  }
}
```

### GET /api/realtime/operations

Get supported real-time operations.

**Response:**
```json
{
  "success": true,
  "data": {
    "operations": {
      "text_analysis": {
        "name": "Text Analysis",
        "description": "Analyze text for sentiment, entities, keywords",
        "capabilities": ["sentiment", "entities", "keywords", "language_detection"]
      },
      "data_processing": {
        "name": "Data Processing",
        "description": "Process and analyze structured data",
        "capabilities": ["statistics", "patterns", "anomalies", "trends"]
      }
    },
    "summary": {
      "total": 4,
      "categories": ["text_processing", "data_processing", "stream_processing"]
    }
  }
}
```

## WebSocket Support

The service supports WebSocket connections for real-time communication:

**Connection URL:** `ws://localhost:3000`

**Events:**
- `process-stream`: Send data for stream processing
- `stream-result`: Receive processing results
- `stream-error`: Receive error notifications

**Example Usage:**
```javascript
const socket = io('http://localhost:3000');

socket.emit('process-stream', {
  streamId: 'your-stream-id',
  data: 'Text to process'
});

socket.on('stream-result', (result) => {
  console.log('Processing result:', result);
});
```

## Status Codes

The API uses standard HTTP status codes:

- `200 OK`: Successful request
- `400 Bad Request`: Invalid request parameters
- `401 Unauthorized`: Authentication required (if enabled)
- `404 Not Found`: Endpoint not found
- `413 Payload Too Large`: File size exceeds limit
- `429 Too Many Requests`: Rate limit exceeded
- `500 Internal Server Error`: Server error
- `503 Service Unavailable`: Service temporarily unavailable

## Rate Limiting

Default rate limits:
- 100 requests per 15 minutes per IP address
- Configurable via environment variables
- Rate limit headers included in responses:
  - `X-RateLimit-Limit`: Request limit
  - `X-RateLimit-Remaining`: Remaining requests
  - `X-RateLimit-Reset`: Reset time

## File Upload Limits

- Maximum file size: 50MB (configurable)
- Supported image formats: JPEG, PNG, WebP, BMP, TIFF
- Supported document formats: PDF
- Maximum batch size: 10 files for OCR, 5 files for vision

## Error Codes

Custom error codes for specific scenarios:

- `VALIDATION_ERROR`: Request validation failed
- `FILE_TOO_LARGE`: Uploaded file exceeds size limit
- `UNSUPPORTED_FORMAT`: File format not supported
- `MODEL_ERROR`: AI model processing error
- `TIMEOUT_ERROR`: Processing timeout
- `STREAM_NOT_FOUND`: Stream ID not found
- `INSUFFICIENT_STORAGE`: Not enough disk space

## SDK and Client Libraries

While no official SDKs are provided, the API is designed to work with standard HTTP clients:

**JavaScript/Node.js:**
```javascript
const axios = require('axios');
const FormData = require('form-data');

// OCR example
const form = new FormData();
form.append('image', fs.createReadStream('image.jpg'));
form.append('engine', 'tesseract');

const response = await axios.post('http://localhost:3000/api/ocr/image', form, {
  headers: form.getHeaders()
});
```

**Python:**
```python
import requests

# Text analysis example
response = requests.post('http://localhost:3000/api/realtime/text/analyze', 
  json={
    'text': 'Sample text for analysis',
    'includeSentiment': True
  }
)
result = response.json()
```

**cURL:**
```bash
# Vision description example
curl -X POST http://localhost:3000/api/vision/describe \
  -F "image=@photo.jpg" \
  -F "detail=high"
```

This comprehensive API reference provides all the information needed to integrate with the Advanced Open-Source AI API Service. For additional examples and use cases, refer to the main documentation and example files.

