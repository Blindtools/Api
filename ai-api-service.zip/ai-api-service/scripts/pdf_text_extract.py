#!/usr/bin/env python3
"""
PDF text extraction script using PyMuPDF and pdfplumber
"""

import sys
import json
import os
import fitz  # PyMuPDF
import pdfplumber
from pathlib import Path

def extract_with_pymupdf(pdf_path, start_page=None, end_page=None):
    """Extract text using PyMuPDF"""
    try:
        doc = fitz.open(pdf_path)
        pages = []
        full_text = ""
        
        start = start_page - 1 if start_page else 0
        end = end_page if end_page else doc.page_count
        
        for page_num in range(start, min(end, doc.page_count)):
            page = doc[page_num]
            text = page.get_text()
            
            pages.append({
                'page': page_num + 1,
                'text': text.strip(),
                'char_count': len(text.strip()),
                'word_count': len(text.strip().split()) if text.strip() else 0
            })
            
            full_text += text + "\n"
        
        doc.close()
        
        return {
            'text': full_text.strip(),
            'pages': pages,
            'total_pages': doc.page_count,
            'method': 'pymupdf'
        }
        
    except Exception as e:
        raise Exception(f"PyMuPDF extraction failed: {str(e)}")

def extract_with_pdfplumber(pdf_path, start_page=None, end_page=None):
    """Extract text using pdfplumber"""
    try:
        pages = []
        full_text = ""
        
        with pdfplumber.open(pdf_path) as pdf:
            total_pages = len(pdf.pages)
            
            start = start_page - 1 if start_page else 0
            end = end_page if end_page else total_pages
            
            for page_num in range(start, min(end, total_pages)):
                page = pdf.pages[page_num]
                text = page.extract_text() or ""
                
                # Extract tables if present
                tables = page.extract_tables()
                table_text = ""
                if tables:
                    for table in tables:
                        for row in table:
                            if row:
                                table_text += " | ".join([cell or "" for cell in row]) + "\n"
                
                combined_text = text + "\n" + table_text if table_text else text
                
                pages.append({
                    'page': page_num + 1,
                    'text': combined_text.strip(),
                    'char_count': len(combined_text.strip()),
                    'word_count': len(combined_text.strip().split()) if combined_text.strip() else 0,
                    'has_tables': len(tables) > 0,
                    'table_count': len(tables)
                })
                
                full_text += combined_text + "\n"
        
        return {
            'text': full_text.strip(),
            'pages': pages,
            'total_pages': total_pages,
            'method': 'pdfplumber'
        }
        
    except Exception as e:
        raise Exception(f"pdfplumber extraction failed: {str(e)}")

def extract_pdf_text(pdf_path, start_page=None, end_page=None):
    """Extract text from PDF using the best available method"""
    
    # Try pdfplumber first (better for tables and complex layouts)
    try:
        result = extract_with_pdfplumber(pdf_path, start_page, end_page)
        
        # Check if we got meaningful text
        if result['text'].strip() and len(result['text'].strip()) > 10:
            return result
    except Exception as e:
        print(f"pdfplumber failed: {e}", file=sys.stderr)
    
    # Fallback to PyMuPDF
    try:
        result = extract_with_pymupdf(pdf_path, start_page, end_page)
        return result
    except Exception as e:
        raise Exception(f"Both PDF extraction methods failed. pdfplumber and PyMuPDF errors: {str(e)}")

def analyze_pdf_content(pdf_path):
    """Analyze PDF to determine if it contains text or is image-based"""
    try:
        doc = fitz.open(pdf_path)
        
        text_pages = 0
        image_pages = 0
        total_text_length = 0
        
        for page_num in range(min(5, doc.page_count)):  # Check first 5 pages
            page = doc[page_num]
            text = page.get_text().strip()
            images = page.get_images()
            
            if len(text) > 50:  # Meaningful text threshold
                text_pages += 1
                total_text_length += len(text)
            
            if len(images) > 0:
                image_pages += 1
        
        doc.close()
        
        # Determine if PDF is text-based or image-based
        is_text_based = text_pages > 0 and total_text_length > 100
        is_image_based = image_pages > text_pages
        
        return {
            'is_text_based': is_text_based,
            'is_image_based': is_image_based,
            'text_pages': text_pages,
            'image_pages': image_pages,
            'avg_text_length': total_text_length / max(text_pages, 1)
        }
        
    except Exception as e:
        return {
            'is_text_based': False,
            'is_image_based': True,
            'error': str(e)
        }

def main():
    if len(sys.argv) < 2:
        print(json.dumps({
            'error': 'Usage: python pdf_text_extract.py <pdf_path> [start_page] [end_page]'
        }))
        sys.exit(1)
    
    pdf_path = sys.argv[1]
    start_page = int(sys.argv[2]) if len(sys.argv) > 2 else None
    end_page = int(sys.argv[3]) if len(sys.argv) > 3 else None
    
    try:
        # Validate input file
        if not os.path.exists(pdf_path):
            raise FileNotFoundError(f"PDF file not found: {pdf_path}")
        
        # Check if file is a PDF
        if not pdf_path.lower().endswith('.pdf'):
            raise ValueError(f"File is not a PDF: {pdf_path}")
        
        # Analyze PDF content
        analysis = analyze_pdf_content(pdf_path)
        
        # Extract text
        result = extract_pdf_text(pdf_path, start_page, end_page)
        
        # Add analysis to result
        result['analysis'] = analysis
        result['success'] = True
        
        # Calculate statistics
        total_chars = len(result['text'])
        total_words = len(result['text'].split()) if result['text'] else 0
        
        result['statistics'] = {
            'total_characters': total_chars,
            'total_words': total_words,
            'pages_processed': len(result['pages']),
            'avg_words_per_page': total_words / len(result['pages']) if result['pages'] else 0
        }
        
        # Output result as JSON
        print(json.dumps(result, ensure_ascii=False, indent=2))
        
    except Exception as e:
        error_result = {
            'error': str(e),
            'success': False,
            'text': '',
            'pages': [],
            'total_pages': 0,
            'method': 'none'
        }
        print(json.dumps(error_result, ensure_ascii=False))
        sys.exit(1)

if __name__ == '__main__':
    main()

