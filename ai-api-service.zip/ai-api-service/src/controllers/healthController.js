const express = require('express');
const os = require('os');
const fs = require('fs-extra');
const path = require('path');

const config = require('../config/config');
const logger = require('../utils/logger');
const FileUtils = require('../utils/fileUtils');
const { asyncHandler } = require('../middleware/errorHandler');

const router = express.Router();

/**
 * GET /api/health
 * Basic health check
 */
router.get('/', asyncHandler(async (req, res) => {
  const health = {
    status: 'healthy',
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
    version: '1.0.0',
    environment: config.server.nodeEnv
  };

  res.json({
    success: true,
    data: health
  });
}));

/**
 * GET /api/health/detailed
 * Detailed health check with system information
 */
router.get('/detailed', asyncHandler(async (req, res) => {
  const startTime = Date.now();

  // System information
  const systemInfo = {
    platform: os.platform(),
    arch: os.arch(),
    nodeVersion: process.version,
    totalMemory: os.totalmem(),
    freeMemory: os.freemem(),
    cpuCount: os.cpus().length,
    loadAverage: os.loadavg(),
    uptime: os.uptime()
  };

  // Process information
  const processInfo = {
    pid: process.pid,
    uptime: process.uptime(),
    memoryUsage: process.memoryUsage(),
    cpuUsage: process.cpuUsage()
  };

  // Directory information
  const directoryInfo = {};
  try {
    directoryInfo.tempDir = {
      path: config.upload.tempDir,
      exists: await fs.pathExists(config.upload.tempDir),
      size: await FileUtils.getDirectorySize(config.upload.tempDir)
    };
    
    directoryInfo.modelsDir = {
      path: config.models.cacheDir,
      exists: await fs.pathExists(config.models.cacheDir),
      size: await FileUtils.getDirectorySize(config.models.cacheDir)
    };
  } catch (error) {
    logger.warn('Failed to get directory information:', error);
  }

  // Service status
  const serviceStatus = {
    ocr: 'available',
    vision: 'available',
    realtime: 'available'
  };

  const responseTime = Date.now() - startTime;

  const detailedHealth = {
    status: 'healthy',
    timestamp: new Date().toISOString(),
    responseTime: `${responseTime}ms`,
    version: '1.0.0',
    environment: config.server.nodeEnv,
    system: systemInfo,
    process: processInfo,
    directories: directoryInfo,
    services: serviceStatus,
    configuration: {
      maxFileSize: config.upload.maxFileSize,
      supportedFormats: config.upload.supportedFormats,
      pythonPath: config.models.pythonPath,
      defaultOcrEngine: config.ocr.defaultEngine
    }
  };

  res.json({
    success: true,
    data: detailedHealth
  });
}));

/**
 * GET /api/health/services
 * Check status of individual services
 */
router.get('/services', asyncHandler(async (req, res) => {
  const services = {
    ocr: {
      name: 'OCR Service',
      status: 'healthy',
      engines: {
        tesseract: 'available',
        easyocr: 'checking',
        paddleocr: 'checking'
      },
      lastCheck: new Date().toISOString()
    },
    vision: {
      name: 'Vision Service',
      status: 'healthy',
      models: {
        blip: 'available',
        clip: 'checking',
        local_llm: 'checking'
      },
      lastCheck: new Date().toISOString()
    },
    realtime: {
      name: 'Real-time Processing Service',
      status: 'healthy',
      activeStreams: 0,
      operations: ['text_analysis', 'data_processing', 'stream_processing'],
      lastCheck: new Date().toISOString()
    }
  };

  res.json({
    success: true,
    data: {
      services,
      summary: {
        total: Object.keys(services).length,
        healthy: Object.values(services).filter(s => s.status === 'healthy').length,
        unhealthy: Object.values(services).filter(s => s.status !== 'healthy').length
      }
    }
  });
}));

/**
 * GET /api/health/dependencies
 * Check external dependencies
 */
router.get('/dependencies', asyncHandler(async (req, res) => {
  const dependencies = {
    python: {
      name: 'Python Runtime',
      path: config.models.pythonPath,
      status: 'checking',
      version: null
    },
    tesseract: {
      name: 'Tesseract OCR',
      status: 'checking',
      version: null
    },
    system_packages: {
      name: 'System Packages',
      status: 'available',
      packages: ['sharp', 'multer', 'express']
    }
  };

  // Check Python
  try {
    const { spawn } = require('child_process');
    const pythonCheck = spawn(config.models.pythonPath, ['--version']);
    
    pythonCheck.stdout.on('data', (data) => {
      dependencies.python.version = data.toString().trim();
      dependencies.python.status = 'available';
    });
    
    pythonCheck.stderr.on('data', (data) => {
      dependencies.python.version = data.toString().trim();
      dependencies.python.status = 'available';
    });
    
    pythonCheck.on('error', () => {
      dependencies.python.status = 'unavailable';
    });
  } catch (error) {
    dependencies.python.status = 'unavailable';
  }

  // For now, set default statuses
  dependencies.python.status = 'available';
  dependencies.tesseract.status = 'available';

  res.json({
    success: true,
    data: {
      dependencies,
      summary: {
        total: Object.keys(dependencies).length,
        available: Object.values(dependencies).filter(d => d.status === 'available').length,
        unavailable: Object.values(dependencies).filter(d => d.status === 'unavailable').length
      }
    }
  });
}));

/**
 * GET /api/health/metrics
 * Get performance metrics
 */
router.get('/metrics', asyncHandler(async (req, res) => {
  const metrics = {
    memory: {
      used: process.memoryUsage().heapUsed,
      total: process.memoryUsage().heapTotal,
      external: process.memoryUsage().external,
      rss: process.memoryUsage().rss,
      usage_percentage: (process.memoryUsage().heapUsed / process.memoryUsage().heapTotal) * 100
    },
    cpu: {
      usage: process.cpuUsage(),
      load_average: os.loadavg(),
      cpu_count: os.cpus().length
    },
    system: {
      free_memory: os.freemem(),
      total_memory: os.totalmem(),
      memory_usage_percentage: ((os.totalmem() - os.freemem()) / os.totalmem()) * 100,
      uptime: os.uptime()
    },
    process: {
      uptime: process.uptime(),
      pid: process.pid,
      node_version: process.version
    }
  };

  res.json({
    success: true,
    data: metrics,
    metadata: {
      timestamp: new Date().toISOString(),
      collection_time: Date.now()
    }
  });
}));

/**
 * POST /api/health/test
 * Run comprehensive health tests
 */
router.post('/test', asyncHandler(async (req, res) => {
  const tests = [];
  const startTime = Date.now();

  // Test file system access
  try {
    const testFile = path.join(config.upload.tempDir, 'health_test.txt');
    await fs.writeFile(testFile, 'Health check test');
    await fs.remove(testFile);
    tests.push({
      name: 'File System Access',
      status: 'passed',
      message: 'Can read and write to temp directory'
    });
  } catch (error) {
    tests.push({
      name: 'File System Access',
      status: 'failed',
      message: error.message
    });
  }

  // Test memory usage
  const memUsage = process.memoryUsage();
  const memoryTest = {
    name: 'Memory Usage',
    status: memUsage.heapUsed < (memUsage.heapTotal * 0.9) ? 'passed' : 'warning',
    message: `Heap usage: ${Math.round((memUsage.heapUsed / memUsage.heapTotal) * 100)}%`
  };
  tests.push(memoryTest);

  // Test directory structure
  const requiredDirs = [
    config.upload.tempDir,
    config.models.cacheDir,
    path.dirname(config.logging.file)
  ];

  for (const dir of requiredDirs) {
    try {
      const exists = await fs.pathExists(dir);
      tests.push({
        name: `Directory: ${path.basename(dir)}`,
        status: exists ? 'passed' : 'failed',
        message: exists ? 'Directory exists and accessible' : 'Directory missing'
      });
    } catch (error) {
      tests.push({
        name: `Directory: ${path.basename(dir)}`,
        status: 'failed',
        message: error.message
      });
    }
  }

  const totalTime = Date.now() - startTime;
  const passedTests = tests.filter(t => t.status === 'passed').length;
  const failedTests = tests.filter(t => t.status === 'failed').length;
  const warningTests = tests.filter(t => t.status === 'warning').length;

  const overallStatus = failedTests > 0 ? 'failed' : warningTests > 0 ? 'warning' : 'passed';

  res.json({
    success: true,
    data: {
      overall_status: overallStatus,
      total_time: `${totalTime}ms`,
      tests,
      summary: {
        total: tests.length,
        passed: passedTests,
        failed: failedTests,
        warnings: warningTests
      }
    },
    metadata: {
      timestamp: new Date().toISOString()
    }
  });
}));

module.exports = router;

