const { spawn } = require('child_process');
const path = require('path');
const fs = require('fs-extra');
const config = require('../config/config');
const logger = require('../utils/logger');
const { ModelError, FileProcessingError } = require('../middleware/errorHandler');

class VisionService {
  constructor() {
    this.pythonPath = config.models.pythonPath;
    this.scriptsDir = path.join(__dirname, '../../scripts');
    this.modelsCache = new Map();
    this.supportedModels = {
      'blip': {
        name: 'BLIP',
        description: 'Bootstrapped Language-Image Pre-training',
        capabilities: ['image_captioning', 'visual_question_answering'],
        sizes: ['base', 'large']
      },
      'clip': {
        name: 'CLIP',
        description: 'Contrastive Language-Image Pre-training',
        capabilities: ['image_classification', 'zero_shot_classification'],
        sizes: ['base', 'large']
      },
      'local_llm': {
        name: 'Local LLM Vision',
        description: 'Local multimodal language model',
        capabilities: ['detailed_description', 'scene_analysis'],
        sizes: ['7b', '13b']
      }
    };
  }

  /**
   * Generate detailed description of an image
   */
  async describeImage(imagePath, options = {}) {
    const {
      model = 'blip',
      detail = 'medium',
      maxLength = 200,
      temperature = 0.7
    } = options;

    try {
      logger.info(`Starting image description: ${imagePath} using ${model}`);
      
      const startTime = Date.now();
      let result;

      switch (model.toLowerCase()) {
        case 'blip':
          result = await this.runBLIPDescription(imagePath, { detail, maxLength });
          break;
        case 'clip':
          result = await this.runCLIPAnalysis(imagePath, options);
          break;
        case 'local_llm':
          result = await this.runLocalLLMVision(imagePath, { detail, maxLength, temperature });
          break;
        default:
          throw new ModelError(`Unsupported vision model: ${model}`);
      }

      const duration = Date.now() - startTime;
      logger.logModelOperation('Image Description', model, duration, true);

      return {
        model,
        description: result.description,
        confidence: result.confidence || 0.8,
        details: result.details || {},
        processingTime: duration,
        metadata: {
          imageSize: await this.getImageMetadata(imagePath),
          modelVersion: result.modelVersion || 'unknown'
        }
      };

    } catch (error) {
      logger.error(`Image description failed for ${imagePath}:`, error);
      throw new ModelError(`Image description failed: ${error.message}`, model);
    }
  }

  /**
   * Analyze image for objects, scenes, and composition
   */
  async analyzeImage(imagePath, options = {}) {
    const {
      includeObjects = true,
      includeScenes = true,
      includeColors = true,
      includeComposition = true,
      confidence = 0.5
    } = options;

    try {
      logger.info(`Starting comprehensive image analysis: ${imagePath}`);
      
      const startTime = Date.now();
      const result = await this.runComprehensiveAnalysis(imagePath, {
        includeObjects,
        includeScenes,
        includeColors,
        includeComposition,
        confidence
      });

      const duration = Date.now() - startTime;
      logger.logModelOperation('Image Analysis', 'comprehensive', duration, true);

      return {
        ...result,
        processingTime: duration,
        metadata: {
          imageSize: await this.getImageMetadata(imagePath),
          analysisTimestamp: new Date().toISOString()
        }
      };

    } catch (error) {
      logger.error(`Image analysis failed for ${imagePath}:`, error);
      throw new ModelError(`Image analysis failed: ${error.message}`, 'comprehensive');
    }
  }

  /**
   * Generate captions for an image
   */
  async generateCaption(imagePath, options = {}) {
    const {
      style = 'descriptive', // 'descriptive', 'creative', 'technical'
      length = 'medium', // 'short', 'medium', 'long'
      count = 1
    } = options;

    try {
      logger.info(`Generating image captions: ${imagePath}`);
      
      const startTime = Date.now();
      const result = await this.runCaptionGeneration(imagePath, {
        style,
        length,
        count
      });

      const duration = Date.now() - startTime;
      logger.logModelOperation('Caption Generation', 'blip', duration, true);

      return {
        captions: result.captions,
        style,
        length,
        processingTime: duration,
        metadata: {
          imageSize: await this.getImageMetadata(imagePath),
          generatedAt: new Date().toISOString()
        }
      };

    } catch (error) {
      logger.error(`Caption generation failed for ${imagePath}:`, error);
      throw new ModelError(`Caption generation failed: ${error.message}`, 'caption');
    }
  }

  /**
   * Answer questions about an image
   */
  async answerQuestion(imagePath, question, options = {}) {
    const {
      model = 'blip',
      confidence = 0.7
    } = options;

    try {
      logger.info(`Answering question about image: ${imagePath}`);
      
      const startTime = Date.now();
      const result = await this.runVisualQuestionAnswering(imagePath, question, {
        model,
        confidence
      });

      const duration = Date.now() - startTime;
      logger.logModelOperation('Visual QA', model, duration, true);

      return {
        question,
        answer: result.answer,
        confidence: result.confidence,
        model,
        processingTime: duration,
        metadata: {
          imageSize: await this.getImageMetadata(imagePath),
          answeredAt: new Date().toISOString()
        }
      };

    } catch (error) {
      logger.error(`Visual QA failed for ${imagePath}:`, error);
      throw new ModelError(`Visual QA failed: ${error.message}`, model);
    }
  }

  /**
   * Run BLIP model for image description
   */
  async runBLIPDescription(imagePath, options) {
    return new Promise((resolve, reject) => {
      const scriptPath = path.join(this.scriptsDir, 'blip_description.py');
      const args = [scriptPath, imagePath, JSON.stringify(options)];
      
      const process = spawn(this.pythonPath, args);
      let stdout = '';
      let stderr = '';

      process.stdout.on('data', (data) => {
        stdout += data.toString();
      });

      process.stderr.on('data', (data) => {
        stderr += data.toString();
      });

      process.on('close', (code) => {
        if (code === 0) {
          try {
            const result = JSON.parse(stdout);
            resolve(result);
          } catch (error) {
            reject(new Error(`Failed to parse BLIP output: ${error.message}`));
          }
        } else {
          reject(new Error(`BLIP process failed: ${stderr}`));
        }
      });

      process.on('error', (error) => {
        reject(new Error(`Failed to start BLIP process: ${error.message}`));
      });
    });
  }

  /**
   * Run CLIP model for image analysis
   */
  async runCLIPAnalysis(imagePath, options) {
    return new Promise((resolve, reject) => {
      const scriptPath = path.join(this.scriptsDir, 'clip_analysis.py');
      const args = [scriptPath, imagePath, JSON.stringify(options)];
      
      const process = spawn(this.pythonPath, args);
      let stdout = '';
      let stderr = '';

      process.stdout.on('data', (data) => {
        stdout += data.toString();
      });

      process.stderr.on('data', (data) => {
        stderr += data.toString();
      });

      process.on('close', (code) => {
        if (code === 0) {
          try {
            const result = JSON.parse(stdout);
            resolve(result);
          } catch (error) {
            reject(new Error(`Failed to parse CLIP output: ${error.message}`));
          }
        } else {
          reject(new Error(`CLIP process failed: ${stderr}`));
        }
      });

      process.on('error', (error) => {
        reject(new Error(`Failed to start CLIP process: ${error.message}`));
      });
    });
  }

  /**
   * Run local LLM for vision tasks
   */
  async runLocalLLMVision(imagePath, options) {
    return new Promise((resolve, reject) => {
      const scriptPath = path.join(this.scriptsDir, 'local_llm_vision.py');
      const args = [scriptPath, imagePath, JSON.stringify(options)];
      
      const process = spawn(this.pythonPath, args);
      let stdout = '';
      let stderr = '';

      process.stdout.on('data', (data) => {
        stdout += data.toString();
      });

      process.stderr.on('data', (data) => {
        stderr += data.toString();
      });

      process.on('close', (code) => {
        if (code === 0) {
          try {
            const result = JSON.parse(stdout);
            resolve(result);
          } catch (error) {
            reject(new Error(`Failed to parse Local LLM output: ${error.message}`));
          }
        } else {
          reject(new Error(`Local LLM process failed: ${stderr}`));
        }
      });

      process.on('error', (error) => {
        reject(new Error(`Failed to start Local LLM process: ${error.message}`));
      });
    });
  }

  /**
   * Run comprehensive image analysis
   */
  async runComprehensiveAnalysis(imagePath, options) {
    return new Promise((resolve, reject) => {
      const scriptPath = path.join(this.scriptsDir, 'comprehensive_analysis.py');
      const args = [scriptPath, imagePath, JSON.stringify(options)];
      
      const process = spawn(this.pythonPath, args);
      let stdout = '';
      let stderr = '';

      process.stdout.on('data', (data) => {
        stdout += data.toString();
      });

      process.stderr.on('data', (data) => {
        stderr += data.toString();
      });

      process.on('close', (code) => {
        if (code === 0) {
          try {
            const result = JSON.parse(stdout);
            resolve(result);
          } catch (error) {
            reject(new Error(`Failed to parse analysis output: ${error.message}`));
          }
        } else {
          reject(new Error(`Analysis process failed: ${stderr}`));
        }
      });

      process.on('error', (error) => {
        reject(new Error(`Failed to start analysis process: ${error.message}`));
      });
    });
  }

  /**
   * Run caption generation
   */
  async runCaptionGeneration(imagePath, options) {
    return new Promise((resolve, reject) => {
      const scriptPath = path.join(this.scriptsDir, 'caption_generation.py');
      const args = [scriptPath, imagePath, JSON.stringify(options)];
      
      const process = spawn(this.pythonPath, args);
      let stdout = '';
      let stderr = '';

      process.stdout.on('data', (data) => {
        stdout += data.toString();
      });

      process.stderr.on('data', (data) => {
        stderr += data.toString();
      });

      process.on('close', (code) => {
        if (code === 0) {
          try {
            const result = JSON.parse(stdout);
            resolve(result);
          } catch (error) {
            reject(new Error(`Failed to parse caption output: ${error.message}`));
          }
        } else {
          reject(new Error(`Caption generation failed: ${stderr}`));
        }
      });

      process.on('error', (error) => {
        reject(new Error(`Failed to start caption generation: ${error.message}`));
      });
    });
  }

  /**
   * Run visual question answering
   */
  async runVisualQuestionAnswering(imagePath, question, options) {
    return new Promise((resolve, reject) => {
      const scriptPath = path.join(this.scriptsDir, 'visual_qa.py');
      const args = [scriptPath, imagePath, question, JSON.stringify(options)];
      
      const process = spawn(this.pythonPath, args);
      let stdout = '';
      let stderr = '';

      process.stdout.on('data', (data) => {
        stdout += data.toString();
      });

      process.stderr.on('data', (data) => {
        stderr += data.toString();
      });

      process.on('close', (code) => {
        if (code === 0) {
          try {
            const result = JSON.parse(stdout);
            resolve(result);
          } catch (error) {
            reject(new Error(`Failed to parse VQA output: ${error.message}`));
          }
        } else {
          reject(new Error(`VQA process failed: ${stderr}`));
        }
      });

      process.on('error', (error) => {
        reject(new Error(`Failed to start VQA process: ${error.message}`));
      });
    });
  }

  /**
   * Get image metadata
   */
  async getImageMetadata(imagePath) {
    try {
      const sharp = require('sharp');
      const metadata = await sharp(imagePath).metadata();
      const stats = await fs.stat(imagePath);
      
      return {
        width: metadata.width,
        height: metadata.height,
        format: metadata.format,
        channels: metadata.channels,
        density: metadata.density,
        fileSize: stats.size,
        aspectRatio: metadata.width / metadata.height
      };
    } catch (error) {
      logger.warn(`Failed to get image metadata for ${imagePath}:`, error);
      return null;
    }
  }

  /**
   * Get supported models and their capabilities
   */
  getSupportedModels() {
    return this.supportedModels;
  }

  /**
   * Health check for vision models
   */
  async healthCheck() {
    const status = {
      blip: false,
      clip: false,
      local_llm: false
    };

    // For now, return mock status
    // In a real implementation, you would test each model
    status.blip = true; // Assume available for demo
    
    return status;
  }

  /**
   * Process multiple images in batch
   */
  async processBatch(images, operation, options = {}) {
    const results = [];
    const errors = [];

    for (const image of images) {
      try {
        let result;
        
        switch (operation) {
          case 'describe':
            result = await this.describeImage(image.path, options);
            break;
          case 'analyze':
            result = await this.analyzeImage(image.path, options);
            break;
          case 'caption':
            result = await this.generateCaption(image.path, options);
            break;
          default:
            throw new Error(`Unsupported operation: ${operation}`);
        }

        results.push({
          filename: image.filename,
          success: true,
          result
        });

      } catch (error) {
        logger.error(`Batch processing failed for ${image.filename}:`, error);
        errors.push({
          filename: image.filename,
          success: false,
          error: error.message
        });
      }
    }

    return {
      results,
      errors,
      summary: {
        total: images.length,
        successful: results.length,
        failed: errors.length
      }
    };
  }
}

module.exports = new VisionService();

