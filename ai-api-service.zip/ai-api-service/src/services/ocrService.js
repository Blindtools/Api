const { spawn } = require('child_process');
const path = require('path');
const fs = require('fs-extra');
const config = require('../config/config');
const logger = require('../utils/logger');
const { ModelError, FileProcessingError } = require('../middleware/errorHandler');

class OCRService {
  constructor() {
    this.pythonPath = config.models.pythonPath;
    this.scriptsDir = path.join(__dirname, '../../scripts');
    this.modelsCache = new Map();
  }

  /**
   * Extract text from image using specified OCR engine
   */
  async extractTextFromImage(imagePath, options = {}) {
    const {
      engine = config.ocr.defaultEngine,
      languages = config.ocr.languages,
      confidence = 0.5
    } = options;

    try {
      logger.info(`Starting OCR extraction from image: ${imagePath} using ${engine}`);
      
      const startTime = Date.now();
      let result;

      switch (engine.toLowerCase()) {
        case 'tesseract':
          result = await this.runTesseractOCR(imagePath, languages);
          break;
        case 'easyocr':
          result = await this.runEasyOCR(imagePath, languages, confidence);
          break;
        case 'paddleocr':
          result = await this.runPaddleOCR(imagePath, languages, confidence);
          break;
        default:
          throw new ModelError(`Unsupported OCR engine: ${engine}`);
      }

      const duration = Date.now() - startTime;
      logger.logModelOperation('OCR', engine, duration, true);

      return {
        engine,
        text: result.text,
        confidence: result.confidence,
        boundingBoxes: result.boundingBoxes || [],
        languages: languages,
        processingTime: duration,
        metadata: {
          imageSize: await this.getImageSize(imagePath),
          detectedLanguages: result.detectedLanguages || []
        }
      };

    } catch (error) {
      logger.error(`OCR extraction failed for ${imagePath}:`, error);
      throw new ModelError(`OCR extraction failed: ${error.message}`, engine);
    }
  }

  /**
   * Extract text from PDF document
   */
  async extractTextFromPDF(pdfPath, options = {}) {
    const {
      engine = config.ocr.defaultEngine,
      languages = config.ocr.languages,
      pageRange = null,
      ocrMode = 'auto' // 'auto', 'text', 'ocr'
    } = options;

    try {
      logger.info(`Starting PDF text extraction: ${pdfPath}`);
      
      const startTime = Date.now();
      
      // First try to extract text directly from PDF
      if (ocrMode === 'auto' || ocrMode === 'text') {
        const textResult = await this.extractPDFText(pdfPath, pageRange);
        
        // If we got meaningful text, return it
        if (textResult.text.trim().length > 50) {
          const duration = Date.now() - startTime;
          logger.logModelOperation('PDF Text Extraction', 'direct', duration, true);
          
          return {
            engine: 'direct',
            text: textResult.text,
            pages: textResult.pages,
            processingTime: duration,
            method: 'direct_text_extraction'
          };
        }
      }

      // If direct text extraction failed or OCR mode is forced, use OCR
      if (ocrMode === 'auto' || ocrMode === 'ocr') {
        const ocrResult = await this.runPDFOCR(pdfPath, engine, languages, pageRange);
        const duration = Date.now() - startTime;
        
        logger.logModelOperation('PDF OCR', engine, duration, true);
        
        return {
          engine,
          text: ocrResult.text,
          pages: ocrResult.pages,
          confidence: ocrResult.confidence,
          processingTime: duration,
          method: 'ocr_extraction'
        };
      }

    } catch (error) {
      logger.error(`PDF extraction failed for ${pdfPath}:`, error);
      throw new FileProcessingError(`PDF extraction failed: ${error.message}`, pdfPath);
    }
  }

  /**
   * Process multiple files in batch
   */
  async processBatch(files, options = {}) {
    const results = [];
    const errors = [];

    for (const file of files) {
      try {
        let result;
        
        if (file.type === 'image') {
          result = await this.extractTextFromImage(file.path, options);
        } else if (file.type === 'pdf') {
          result = await this.extractTextFromPDF(file.path, options);
        } else {
          throw new Error(`Unsupported file type: ${file.type}`);
        }

        results.push({
          filename: file.filename,
          success: true,
          result
        });

      } catch (error) {
        logger.error(`Batch processing failed for ${file.filename}:`, error);
        errors.push({
          filename: file.filename,
          success: false,
          error: error.message
        });
      }
    }

    return {
      results,
      errors,
      summary: {
        total: files.length,
        successful: results.length,
        failed: errors.length
      }
    };
  }

  /**
   * Run Tesseract OCR
   */
  async runTesseractOCR(imagePath, languages) {
    return new Promise((resolve, reject) => {
      const scriptPath = path.join(this.scriptsDir, 'tesseract_ocr.py');
      const args = [scriptPath, imagePath, languages.join('+')];
      
      const process = spawn(this.pythonPath, args);
      let stdout = '';
      let stderr = '';

      process.stdout.on('data', (data) => {
        stdout += data.toString();
      });

      process.stderr.on('data', (data) => {
        stderr += data.toString();
      });

      process.on('close', (code) => {
        if (code === 0) {
          try {
            const result = JSON.parse(stdout);
            resolve(result);
          } catch (error) {
            reject(new Error(`Failed to parse Tesseract output: ${error.message}`));
          }
        } else {
          reject(new Error(`Tesseract process failed: ${stderr}`));
        }
      });

      process.on('error', (error) => {
        reject(new Error(`Failed to start Tesseract process: ${error.message}`));
      });
    });
  }

  /**
   * Run EasyOCR
   */
  async runEasyOCR(imagePath, languages, confidence) {
    return new Promise((resolve, reject) => {
      const scriptPath = path.join(this.scriptsDir, 'easyocr_process.py');
      const args = [scriptPath, imagePath, JSON.stringify(languages), confidence.toString()];
      
      const process = spawn(this.pythonPath, args);
      let stdout = '';
      let stderr = '';

      process.stdout.on('data', (data) => {
        stdout += data.toString();
      });

      process.stderr.on('data', (data) => {
        stderr += data.toString();
      });

      process.on('close', (code) => {
        if (code === 0) {
          try {
            const result = JSON.parse(stdout);
            resolve(result);
          } catch (error) {
            reject(new Error(`Failed to parse EasyOCR output: ${error.message}`));
          }
        } else {
          reject(new Error(`EasyOCR process failed: ${stderr}`));
        }
      });

      process.on('error', (error) => {
        reject(new Error(`Failed to start EasyOCR process: ${error.message}`));
      });
    });
  }

  /**
   * Run PaddleOCR
   */
  async runPaddleOCR(imagePath, languages, confidence) {
    return new Promise((resolve, reject) => {
      const scriptPath = path.join(this.scriptsDir, 'paddleocr_process.py');
      const args = [scriptPath, imagePath, JSON.stringify(languages), confidence.toString()];
      
      const process = spawn(this.pythonPath, args);
      let stdout = '';
      let stderr = '';

      process.stdout.on('data', (data) => {
        stdout += data.toString();
      });

      process.stderr.on('data', (data) => {
        stderr += data.toString();
      });

      process.on('close', (code) => {
        if (code === 0) {
          try {
            const result = JSON.parse(stdout);
            resolve(result);
          } catch (error) {
            reject(new Error(`Failed to parse PaddleOCR output: ${error.message}`));
          }
        } else {
          reject(new Error(`PaddleOCR process failed: ${stderr}`));
        }
      });

      process.on('error', (error) => {
        reject(new Error(`Failed to start PaddleOCR process: ${error.message}`));
      });
    });
  }

  /**
   * Extract text directly from PDF
   */
  async extractPDFText(pdfPath, pageRange) {
    return new Promise((resolve, reject) => {
      const scriptPath = path.join(this.scriptsDir, 'pdf_text_extract.py');
      const args = [scriptPath, pdfPath];
      
      if (pageRange) {
        args.push(pageRange.start.toString(), pageRange.end.toString());
      }
      
      const process = spawn(this.pythonPath, args);
      let stdout = '';
      let stderr = '';

      process.stdout.on('data', (data) => {
        stdout += data.toString();
      });

      process.stderr.on('data', (data) => {
        stderr += data.toString();
      });

      process.on('close', (code) => {
        if (code === 0) {
          try {
            const result = JSON.parse(stdout);
            resolve(result);
          } catch (error) {
            reject(new Error(`Failed to parse PDF text output: ${error.message}`));
          }
        } else {
          reject(new Error(`PDF text extraction failed: ${stderr}`));
        }
      });

      process.on('error', (error) => {
        reject(new Error(`Failed to start PDF text extraction: ${error.message}`));
      });
    });
  }

  /**
   * Run OCR on PDF pages
   */
  async runPDFOCR(pdfPath, engine, languages, pageRange) {
    return new Promise((resolve, reject) => {
      const scriptPath = path.join(this.scriptsDir, 'pdf_ocr_process.py');
      const args = [scriptPath, pdfPath, engine, JSON.stringify(languages)];
      
      if (pageRange) {
        args.push(pageRange.start.toString(), pageRange.end.toString());
      }
      
      const process = spawn(this.pythonPath, args);
      let stdout = '';
      let stderr = '';

      process.stdout.on('data', (data) => {
        stdout += data.toString();
      });

      process.stderr.on('data', (data) => {
        stderr += data.toString();
      });

      process.on('close', (code) => {
        if (code === 0) {
          try {
            const result = JSON.parse(stdout);
            resolve(result);
          } catch (error) {
            reject(new Error(`Failed to parse PDF OCR output: ${error.message}`));
          }
        } else {
          reject(new Error(`PDF OCR process failed: ${stderr}`));
        }
      });

      process.on('error', (error) => {
        reject(new Error(`Failed to start PDF OCR process: ${error.message}`));
      });
    });
  }

  /**
   * Get image dimensions
   */
  async getImageSize(imagePath) {
    try {
      const sharp = require('sharp');
      const metadata = await sharp(imagePath).metadata();
      return {
        width: metadata.width,
        height: metadata.height,
        format: metadata.format
      };
    } catch (error) {
      logger.warn(`Failed to get image size for ${imagePath}:`, error);
      return null;
    }
  }

  /**
   * Get supported languages for each engine
   */
  getSupportedLanguages() {
    return {
      tesseract: [
        'eng', 'spa', 'fra', 'deu', 'ita', 'por', 'rus', 'jpn', 'kor', 'chi_sim', 'chi_tra', 'ara'
      ],
      easyocr: [
        'en', 'es', 'fr', 'de', 'it', 'pt', 'ru', 'ja', 'ko', 'zh', 'ar', 'hi', 'th', 'vi'
      ],
      paddleocr: [
        'en', 'ch', 'ta', 'te', 'ka', 'latin', 'arabic', 'cyrillic', 'devanagari'
      ]
    };
  }

  /**
   * Health check for OCR engines
   */
  async healthCheck() {
    const status = {
      tesseract: false,
      easyocr: false,
      paddleocr: false
    };

    try {
      // Test Tesseract
      await this.runTesseractOCR(path.join(__dirname, '../../test_image.png'), ['eng']);
      status.tesseract = true;
    } catch (error) {
      logger.warn('Tesseract health check failed:', error.message);
    }

    // Add similar checks for other engines...

    return status;
  }
}

module.exports = new OCRService();

