const { spawn } = require('child_process');
const path = require('path');
const fs = require('fs-extra');
const EventEmitter = require('events');
const config = require('../config/config');
const logger = require('../utils/logger');
const { ModelError, TimeoutError } = require('../middleware/errorHandler');

class RealtimeService extends EventEmitter {
  constructor() {
    super();
    this.pythonPath = config.models.pythonPath;
    this.scriptsDir = path.join(__dirname, '../../scripts');
    this.activeProcesses = new Map();
    this.processingQueue = [];
    this.isProcessing = false;
    
    this.supportedOperations = {
      'text_analysis': {
        name: 'Text Analysis',
        description: 'Analyze text for sentiment, entities, keywords',
        capabilities: ['sentiment', 'entities', 'keywords', 'language_detection']
      },
      'data_processing': {
        name: 'Data Processing',
        description: 'Process and analyze structured data',
        capabilities: ['statistics', 'patterns', 'anomalies', 'trends']
      },
      'content_generation': {
        name: 'Content Generation',
        description: 'Generate text content using local models',
        capabilities: ['summarization', 'completion', 'translation', 'paraphrasing']
      },
      'stream_processing': {
        name: 'Stream Processing',
        description: 'Process continuous data streams',
        capabilities: ['real_time_analysis', 'event_detection', 'monitoring']
      }
    };
  }

  /**
   * Process text data in real-time
   */
  async processText(text, options = {}) {
    const {
      operation = 'text_analysis',
      includeEntities = true,
      includeSentiment = true,
      includeKeywords = true,
      language = 'auto'
    } = options;

    try {
      logger.info(`Processing text with operation: ${operation}`);
      
      const startTime = Date.now();
      let result;

      switch (operation) {
        case 'text_analysis':
          result = await this.runTextAnalysis(text, {
            includeEntities,
            includeSentiment,
            includeKeywords,
            language
          });
          break;
        case 'content_generation':
          result = await this.runContentGeneration(text, options);
          break;
        case 'summarization':
          result = await this.runSummarization(text, options);
          break;
        case 'translation':
          result = await this.runTranslation(text, options);
          break;
        default:
          throw new ModelError(`Unsupported text operation: ${operation}`);
      }

      const duration = Date.now() - startTime;
      logger.logModelOperation('Text Processing', operation, duration, true);

      return {
        operation,
        result,
        processingTime: duration,
        metadata: {
          textLength: text.length,
          wordCount: text.split(/\s+/).length,
          processedAt: new Date().toISOString()
        }
      };

    } catch (error) {
      logger.error(`Text processing failed:`, error);
      throw new ModelError(`Text processing failed: ${error.message}`, operation);
    }
  }

  /**
   * Process structured data
   */
  async processData(data, options = {}) {
    const {
      operation = 'data_processing',
      includeStatistics = true,
      includePatterns = true,
      includeAnomalies = false
    } = options;

    try {
      logger.info(`Processing data with operation: ${operation}`);
      
      const startTime = Date.now();
      const result = await this.runDataAnalysis(data, {
        includeStatistics,
        includePatterns,
        includeAnomalies
      });

      const duration = Date.now() - startTime;
      logger.logModelOperation('Data Processing', operation, duration, true);

      return {
        operation,
        result,
        processingTime: duration,
        metadata: {
          dataSize: JSON.stringify(data).length,
          dataType: Array.isArray(data) ? 'array' : typeof data,
          processedAt: new Date().toISOString()
        }
      };

    } catch (error) {
      logger.error(`Data processing failed:`, error);
      throw new ModelError(`Data processing failed: ${error.message}`, operation);
    }
  }

  /**
   * Start real-time stream processing
   */
  async startStreamProcessing(streamId, options = {}) {
    const {
      operation = 'stream_processing',
      batchSize = 10,
      interval = 1000,
      timeout = 30000
    } = options;

    try {
      logger.info(`Starting stream processing: ${streamId}`);

      if (this.activeProcesses.has(streamId)) {
        throw new Error(`Stream ${streamId} is already being processed`);
      }

      const streamProcessor = {
        id: streamId,
        operation,
        options,
        startTime: Date.now(),
        processedCount: 0,
        buffer: [],
        isActive: true
      };

      this.activeProcesses.set(streamId, streamProcessor);

      // Start processing loop
      this.processStreamLoop(streamId);

      return {
        streamId,
        status: 'started',
        operation,
        startTime: streamProcessor.startTime
      };

    } catch (error) {
      logger.error(`Failed to start stream processing:`, error);
      throw error;
    }
  }

  /**
   * Add data to stream
   */
  async addToStream(streamId, data) {
    try {
      const processor = this.activeProcesses.get(streamId);
      
      if (!processor) {
        throw new Error(`Stream ${streamId} not found`);
      }

      if (!processor.isActive) {
        throw new Error(`Stream ${streamId} is not active`);
      }

      processor.buffer.push({
        data,
        timestamp: Date.now()
      });

      this.emit('streamData', {
        streamId,
        bufferSize: processor.buffer.length,
        timestamp: Date.now()
      });

      return {
        streamId,
        bufferSize: processor.buffer.length,
        status: 'added'
      };

    } catch (error) {
      logger.error(`Failed to add data to stream ${streamId}:`, error);
      throw error;
    }
  }

  /**
   * Stop stream processing
   */
  async stopStreamProcessing(streamId) {
    try {
      const processor = this.activeProcesses.get(streamId);
      
      if (!processor) {
        throw new Error(`Stream ${streamId} not found`);
      }

      processor.isActive = false;
      
      const summary = {
        streamId,
        status: 'stopped',
        duration: Date.now() - processor.startTime,
        processedCount: processor.processedCount,
        finalBufferSize: processor.buffer.length
      };

      // Clean up after a delay to allow final processing
      setTimeout(() => {
        this.activeProcesses.delete(streamId);
      }, 5000);

      logger.info(`Stream processing stopped: ${streamId}`);
      
      return summary;

    } catch (error) {
      logger.error(`Failed to stop stream processing:`, error);
      throw error;
    }
  }

  /**
   * Get stream status
   */
  getStreamStatus(streamId) {
    const processor = this.activeProcesses.get(streamId);
    
    if (!processor) {
      return {
        streamId,
        status: 'not_found'
      };
    }

    return {
      streamId,
      status: processor.isActive ? 'active' : 'inactive',
      operation: processor.operation,
      startTime: processor.startTime,
      duration: Date.now() - processor.startTime,
      processedCount: processor.processedCount,
      bufferSize: processor.buffer.length
    };
  }

  /**
   * Get all active streams
   */
  getActiveStreams() {
    const streams = [];
    
    for (const [streamId, processor] of this.activeProcesses) {
      streams.push({
        streamId,
        status: processor.isActive ? 'active' : 'inactive',
        operation: processor.operation,
        startTime: processor.startTime,
        duration: Date.now() - processor.startTime,
        processedCount: processor.processedCount,
        bufferSize: processor.buffer.length
      });
    }

    return {
      streams,
      totalActive: streams.filter(s => s.status === 'active').length,
      totalStreams: streams.length
    };
  }

  /**
   * Process stream loop
   */
  async processStreamLoop(streamId) {
    const processor = this.activeProcesses.get(streamId);
    
    if (!processor || !processor.isActive) {
      return;
    }

    try {
      if (processor.buffer.length >= processor.options.batchSize) {
        // Process batch
        const batch = processor.buffer.splice(0, processor.options.batchSize);
        const result = await this.processBatch(batch, processor.operation);
        
        processor.processedCount += batch.length;
        
        this.emit('streamResult', {
          streamId,
          result,
          processedCount: processor.processedCount,
          timestamp: Date.now()
        });
      }

      // Schedule next processing cycle
      if (processor.isActive) {
        setTimeout(() => {
          this.processStreamLoop(streamId);
        }, processor.options.interval);
      }

    } catch (error) {
      logger.error(`Stream processing error for ${streamId}:`, error);
      
      this.emit('streamError', {
        streamId,
        error: error.message,
        timestamp: Date.now()
      });
    }
  }

  /**
   * Process batch of data
   */
  async processBatch(batch, operation) {
    try {
      const results = [];
      
      for (const item of batch) {
        if (typeof item.data === 'string') {
          const result = await this.processText(item.data, { operation });
          results.push({
            timestamp: item.timestamp,
            result: result.result
          });
        } else {
          const result = await this.processData(item.data, { operation });
          results.push({
            timestamp: item.timestamp,
            result: result.result
          });
        }
      }

      return {
        batchSize: batch.length,
        results,
        processedAt: Date.now()
      };

    } catch (error) {
      throw new Error(`Batch processing failed: ${error.message}`);
    }
  }

  /**
   * Run text analysis
   */
  async runTextAnalysis(text, options) {
    return new Promise((resolve, reject) => {
      const scriptPath = path.join(this.scriptsDir, 'text_analysis.py');
      const args = [scriptPath, text, JSON.stringify(options)];
      
      const process = spawn(this.pythonPath, args);
      let stdout = '';
      let stderr = '';

      process.stdout.on('data', (data) => {
        stdout += data.toString();
      });

      process.stderr.on('data', (data) => {
        stderr += data.toString();
      });

      process.on('close', (code) => {
        if (code === 0) {
          try {
            const result = JSON.parse(stdout);
            resolve(result);
          } catch (error) {
            reject(new Error(`Failed to parse text analysis output: ${error.message}`));
          }
        } else {
          reject(new Error(`Text analysis process failed: ${stderr}`));
        }
      });

      process.on('error', (error) => {
        reject(new Error(`Failed to start text analysis process: ${error.message}`));
      });
    });
  }

  /**
   * Run data analysis
   */
  async runDataAnalysis(data, options) {
    return new Promise((resolve, reject) => {
      const scriptPath = path.join(this.scriptsDir, 'data_analysis.py');
      const args = [scriptPath, JSON.stringify(data), JSON.stringify(options)];
      
      const process = spawn(this.pythonPath, args);
      let stdout = '';
      let stderr = '';

      process.stdout.on('data', (data) => {
        stdout += data.toString();
      });

      process.stderr.on('data', (data) => {
        stderr += data.toString();
      });

      process.on('close', (code) => {
        if (code === 0) {
          try {
            const result = JSON.parse(stdout);
            resolve(result);
          } catch (error) {
            reject(new Error(`Failed to parse data analysis output: ${error.message}`));
          }
        } else {
          reject(new Error(`Data analysis process failed: ${stderr}`));
        }
      });

      process.on('error', (error) => {
        reject(new Error(`Failed to start data analysis process: ${error.message}`));
      });
    });
  }

  /**
   * Run content generation
   */
  async runContentGeneration(text, options) {
    return new Promise((resolve, reject) => {
      const scriptPath = path.join(this.scriptsDir, 'content_generation.py');
      const args = [scriptPath, text, JSON.stringify(options)];
      
      const process = spawn(this.pythonPath, args);
      let stdout = '';
      let stderr = '';

      process.stdout.on('data', (data) => {
        stdout += data.toString();
      });

      process.stderr.on('data', (data) => {
        stderr += data.toString();
      });

      process.on('close', (code) => {
        if (code === 0) {
          try {
            const result = JSON.parse(stdout);
            resolve(result);
          } catch (error) {
            reject(new Error(`Failed to parse content generation output: ${error.message}`));
          }
        } else {
          reject(new Error(`Content generation process failed: ${stderr}`));
        }
      });

      process.on('error', (error) => {
        reject(new Error(`Failed to start content generation process: ${error.message}`));
      });
    });
  }

  /**
   * Run summarization
   */
  async runSummarization(text, options) {
    // For now, return a simple extractive summary
    const sentences = text.split(/[.!?]+/).filter(s => s.trim().length > 0);
    const maxSentences = options.maxSentences || 3;
    
    // Simple extractive summarization - take first few sentences
    const summary = sentences.slice(0, maxSentences).join('. ') + '.';
    
    return {
      summary,
      originalLength: text.length,
      summaryLength: summary.length,
      compressionRatio: summary.length / text.length,
      method: 'extractive'
    };
  }

  /**
   * Run translation (mock implementation)
   */
  async runTranslation(text, options) {
    const { targetLanguage = 'en', sourceLanguage = 'auto' } = options;
    
    // Mock translation - in a real implementation, you would use a translation model
    return {
      translatedText: `[Translated to ${targetLanguage}] ${text}`,
      sourceLanguage: sourceLanguage === 'auto' ? 'detected' : sourceLanguage,
      targetLanguage,
      confidence: 0.8,
      method: 'mock_translation'
    };
  }

  /**
   * Get supported operations
   */
  getSupportedOperations() {
    return this.supportedOperations;
  }

  /**
   * Health check
   */
  async healthCheck() {
    return {
      status: 'healthy',
      activeStreams: this.activeProcesses.size,
      queueSize: this.processingQueue.length,
      supportedOperations: Object.keys(this.supportedOperations),
      timestamp: new Date().toISOString()
    };
  }
}

module.exports = new RealtimeService();

