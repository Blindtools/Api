const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs-extra');
const { body, validationResult } = require('express-validator');

const visionService = require('../services/visionService');
const config = require('../config/config');
const logger = require('../utils/logger');
const FileUtils = require('../utils/fileUtils');
const { asyncHandler, ValidationError } = require('../middleware/errorHandler');

const router = express.Router();

// Configure multer for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, config.upload.tempDir);
  },
  filename: (req, file, cb) => {
    const uniqueName = FileUtils.generateUniqueFilename(file.originalname);
    cb(null, uniqueName);
  }
});

const upload = multer({
  storage,
  limits: {
    fileSize: 20 * 1024 * 1024, // 20MB
    files: 5
  },
  fileFilter: (req, file, cb) => {
    const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp', 'image/bmp', 'image/tiff'];
    
    if (allowedTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error(`Unsupported image type: ${file.mimetype}`), false);
    }
  }
});

/**
 * POST /api/vision/describe
 * Generate detailed description of an image
 */
router.post('/describe',
  upload.single('image'),
  [
    body('model').optional().isIn(['blip', 'clip', 'local_llm']),
    body('detail').optional().isIn(['low', 'medium', 'high']),
    body('maxLength').optional().isInt({ min: 50, max: 500 }),
    body('temperature').optional().isFloat({ min: 0, max: 2 })
  ],
  asyncHandler(async (req, res) => {
    // Validate request
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      throw new ValidationError('Validation failed', errors.array());
    }

    if (!req.file) {
      throw new ValidationError('No image file provided');
    }

    const {
      model = 'blip',
      detail = 'medium',
      maxLength = 200,
      temperature = 0.7
    } = req.body;

    try {
      logger.info(`Processing image description request: ${req.file.originalname}`);

      // Process image
      const result = await visionService.describeImage(req.file.path, {
        model,
        detail,
        maxLength: parseInt(maxLength),
        temperature: parseFloat(temperature)
      });

      // Clean up uploaded file
      await FileUtils.deleteFile(req.file.path);

      res.json({
        success: true,
        data: result,
        metadata: {
          filename: req.file.originalname,
          fileSize: req.file.size,
          mimeType: req.file.mimetype,
          timestamp: new Date().toISOString()
        }
      });

    } catch (error) {
      // Clean up uploaded file on error
      if (req.file && req.file.path) {
        await FileUtils.deleteFile(req.file.path);
      }
      throw error;
    }
  })
);

/**
 * POST /api/vision/analyze
 * Perform comprehensive image analysis
 */
router.post('/analyze',
  upload.single('image'),
  [
    body('includeObjects').optional().isBoolean(),
    body('includeScenes').optional().isBoolean(),
    body('includeColors').optional().isBoolean(),
    body('includeComposition').optional().isBoolean(),
    body('confidence').optional().isFloat({ min: 0, max: 1 })
  ],
  asyncHandler(async (req, res) => {
    // Validate request
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      throw new ValidationError('Validation failed', errors.array());
    }

    if (!req.file) {
      throw new ValidationError('No image file provided');
    }

    const {
      includeObjects = true,
      includeScenes = true,
      includeColors = true,
      includeComposition = true,
      confidence = 0.5
    } = req.body;

    try {
      logger.info(`Processing image analysis request: ${req.file.originalname}`);

      // Process image
      const result = await visionService.analyzeImage(req.file.path, {
        includeObjects: includeObjects === 'true' || includeObjects === true,
        includeScenes: includeScenes === 'true' || includeScenes === true,
        includeColors: includeColors === 'true' || includeColors === true,
        includeComposition: includeComposition === 'true' || includeComposition === true,
        confidence: parseFloat(confidence)
      });

      // Clean up uploaded file
      await FileUtils.deleteFile(req.file.path);

      res.json({
        success: true,
        data: result,
        metadata: {
          filename: req.file.originalname,
          fileSize: req.file.size,
          mimeType: req.file.mimetype,
          timestamp: new Date().toISOString()
        }
      });

    } catch (error) {
      // Clean up uploaded file on error
      if (req.file && req.file.path) {
        await FileUtils.deleteFile(req.file.path);
      }
      throw error;
    }
  })
);

/**
 * POST /api/vision/caption
 * Generate captions for an image
 */
router.post('/caption',
  upload.single('image'),
  [
    body('style').optional().isIn(['descriptive', 'creative', 'technical']),
    body('length').optional().isIn(['short', 'medium', 'long']),
    body('count').optional().isInt({ min: 1, max: 5 })
  ],
  asyncHandler(async (req, res) => {
    // Validate request
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      throw new ValidationError('Validation failed', errors.array());
    }

    if (!req.file) {
      throw new ValidationError('No image file provided');
    }

    const {
      style = 'descriptive',
      length = 'medium',
      count = 1
    } = req.body;

    try {
      logger.info(`Processing image caption request: ${req.file.originalname}`);

      // Process image
      const result = await visionService.generateCaption(req.file.path, {
        style,
        length,
        count: parseInt(count)
      });

      // Clean up uploaded file
      await FileUtils.deleteFile(req.file.path);

      res.json({
        success: true,
        data: result,
        metadata: {
          filename: req.file.originalname,
          fileSize: req.file.size,
          mimeType: req.file.mimetype,
          timestamp: new Date().toISOString()
        }
      });

    } catch (error) {
      // Clean up uploaded file on error
      if (req.file && req.file.path) {
        await FileUtils.deleteFile(req.file.path);
      }
      throw error;
    }
  })
);

/**
 * POST /api/vision/question
 * Answer questions about an image
 */
router.post('/question',
  upload.single('image'),
  [
    body('question').notEmpty().isLength({ min: 5, max: 200 }),
    body('model').optional().isIn(['blip', 'local_llm']),
    body('confidence').optional().isFloat({ min: 0, max: 1 })
  ],
  asyncHandler(async (req, res) => {
    // Validate request
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      throw new ValidationError('Validation failed', errors.array());
    }

    if (!req.file) {
      throw new ValidationError('No image file provided');
    }

    const {
      question,
      model = 'blip',
      confidence = 0.7
    } = req.body;

    try {
      logger.info(`Processing visual Q&A request: ${req.file.originalname}`);

      // Process image
      const result = await visionService.answerQuestion(req.file.path, question, {
        model,
        confidence: parseFloat(confidence)
      });

      // Clean up uploaded file
      await FileUtils.deleteFile(req.file.path);

      res.json({
        success: true,
        data: result,
        metadata: {
          filename: req.file.originalname,
          fileSize: req.file.size,
          mimeType: req.file.mimetype,
          timestamp: new Date().toISOString()
        }
      });

    } catch (error) {
      // Clean up uploaded file on error
      if (req.file && req.file.path) {
        await FileUtils.deleteFile(req.file.path);
      }
      throw error;
    }
  })
);

/**
 * POST /api/vision/batch
 * Process multiple images in batch
 */
router.post('/batch',
  upload.array('images', 5),
  [
    body('operation').notEmpty().isIn(['describe', 'analyze', 'caption']),
    body('model').optional().isIn(['blip', 'clip', 'local_llm']),
    body('detail').optional().isIn(['low', 'medium', 'high'])
  ],
  asyncHandler(async (req, res) => {
    // Validate request
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      throw new ValidationError('Validation failed', errors.array());
    }

    if (!req.files || req.files.length === 0) {
      throw new ValidationError('No image files provided');
    }

    const {
      operation,
      model = 'blip',
      detail = 'medium'
    } = req.body;

    try {
      logger.info(`Processing batch vision request: ${req.files.length} images`);

      // Prepare images for processing
      const images = req.files.map(file => ({
        filename: file.originalname,
        path: file.path
      }));

      // Process batch
      const result = await visionService.processBatch(images, operation, {
        model,
        detail
      });

      // Clean up uploaded files
      for (const file of req.files) {
        await FileUtils.deleteFile(file.path);
      }

      res.json({
        success: true,
        data: result,
        metadata: {
          totalImages: req.files.length,
          operation,
          timestamp: new Date().toISOString()
        }
      });

    } catch (error) {
      // Clean up uploaded files on error
      if (req.files) {
        for (const file of req.files) {
          await FileUtils.deleteFile(file.path);
        }
      }
      throw error;
    }
  })
);

/**
 * GET /api/vision/models
 * Get available vision models and their capabilities
 */
router.get('/models', asyncHandler(async (req, res) => {
  const supportedModels = visionService.getSupportedModels();
  const modelStatus = await visionService.healthCheck();
  
  const models = Object.keys(supportedModels).map(key => ({
    id: key,
    ...supportedModels[key],
    available: modelStatus[key] || false
  }));
  
  res.json({
    success: true,
    data: {
      models,
      summary: {
        total: models.length,
        available: models.filter(m => m.available).length
      }
    },
    metadata: {
      timestamp: new Date().toISOString()
    }
  });
}));

/**
 * GET /api/vision/capabilities
 * Get vision service capabilities
 */
router.get('/capabilities', asyncHandler(async (req, res) => {
  const capabilities = {
    operations: [
      {
        name: 'describe',
        description: 'Generate detailed descriptions of images',
        endpoint: '/api/vision/describe',
        methods: ['POST'],
        parameters: ['model', 'detail', 'maxLength', 'temperature']
      },
      {
        name: 'analyze',
        description: 'Comprehensive image analysis including objects, scenes, colors',
        endpoint: '/api/vision/analyze',
        methods: ['POST'],
        parameters: ['includeObjects', 'includeScenes', 'includeColors', 'includeComposition']
      },
      {
        name: 'caption',
        description: 'Generate captions for images',
        endpoint: '/api/vision/caption',
        methods: ['POST'],
        parameters: ['style', 'length', 'count']
      },
      {
        name: 'question',
        description: 'Answer questions about images',
        endpoint: '/api/vision/question',
        methods: ['POST'],
        parameters: ['question', 'model', 'confidence']
      },
      {
        name: 'batch',
        description: 'Process multiple images in batch',
        endpoint: '/api/vision/batch',
        methods: ['POST'],
        parameters: ['operation', 'model', 'detail']
      }
    ],
    supportedFormats: ['JPEG', 'PNG', 'WebP', 'BMP', 'TIFF'],
    maxFileSize: '20MB',
    maxBatchSize: 5
  };
  
  res.json({
    success: true,
    data: capabilities,
    metadata: {
      timestamp: new Date().toISOString()
    }
  });
}));

/**
 * POST /api/vision/test
 * Test vision functionality
 */
router.post('/test', asyncHandler(async (req, res) => {
  const { model = 'blip' } = req.body;
  
  try {
    // Return a mock test response
    res.json({
      success: true,
      data: {
        model,
        test: 'Vision service test completed',
        status: 'available',
        sampleDescription: 'This is a test of the vision service functionality.'
      },
      metadata: {
        timestamp: new Date().toISOString()
      }
    });
    
  } catch (error) {
    throw error;
  }
}));

module.exports = router;

