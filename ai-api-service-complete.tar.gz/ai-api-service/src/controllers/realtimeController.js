const express = require('express');
const { body, validationResult } = require('express-validator');
const { v4: uuidv4 } = require('uuid');

const realtimeService = require('../services/realtimeService');
const config = require('../config/config');
const logger = require('../utils/logger');
const { asyncHandler, ValidationError } = require('../middleware/errorHandler');

const router = express.Router();

/**
 * POST /api/realtime/process
 * Process data in real-time
 */
router.post('/process',
  [
    body('data').notEmpty(),
    body('operation').optional().isIn(['text_analysis', 'data_processing', 'content_generation', 'summarization', 'translation']),
    body('options').optional().isObject()
  ],
  asyncHandler(async (req, res) => {
    // Validate request
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      throw new ValidationError('Validation failed', errors.array());
    }

    const {
      data,
      operation = 'text_analysis',
      options = {}
    } = req.body;

    try {
      logger.info(`Processing real-time request with operation: ${operation}`);

      let result;

      if (typeof data === 'string') {
        result = await realtimeService.processText(data, { operation, ...options });
      } else {
        result = await realtimeService.processData(data, { operation, ...options });
      }

      res.json({
        success: true,
        data: result,
        metadata: {
          operation,
          timestamp: new Date().toISOString(),
          requestId: uuidv4()
        }
      });

    } catch (error) {
      throw error;
    }
  })
);

/**
 * POST /api/realtime/stream/start
 * Start a real-time processing stream
 */
router.post('/stream/start',
  [
    body('operation').optional().isIn(['text_analysis', 'data_processing', 'stream_processing']),
    body('batchSize').optional().isInt({ min: 1, max: 100 }),
    body('interval').optional().isInt({ min: 100, max: 10000 }),
    body('timeout').optional().isInt({ min: 1000, max: 300000 })
  ],
  asyncHandler(async (req, res) => {
    // Validate request
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      throw new ValidationError('Validation failed', errors.array());
    }

    const {
      operation = 'stream_processing',
      batchSize = 10,
      interval = 1000,
      timeout = 30000
    } = req.body;

    try {
      const streamId = uuidv4();
      
      logger.info(`Starting stream processing: ${streamId}`);

      const result = await realtimeService.startStreamProcessing(streamId, {
        operation,
        batchSize: parseInt(batchSize),
        interval: parseInt(interval),
        timeout: parseInt(timeout)
      });

      res.json({
        success: true,
        data: {
          ...result,
          streamId
        },
        metadata: {
          timestamp: new Date().toISOString()
        }
      });

    } catch (error) {
      throw error;
    }
  })
);

/**
 * POST /api/realtime/stream/:streamId/add
 * Add data to a processing stream
 */
router.post('/stream/:streamId/add',
  [
    body('data').notEmpty()
  ],
  asyncHandler(async (req, res) => {
    // Validate request
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      throw new ValidationError('Validation failed', errors.array());
    }

    const { streamId } = req.params;
    const { data } = req.body;

    try {
      logger.info(`Adding data to stream: ${streamId}`);

      const result = await realtimeService.addToStream(streamId, data);

      res.json({
        success: true,
        data: result,
        metadata: {
          timestamp: new Date().toISOString()
        }
      });

    } catch (error) {
      throw error;
    }
  })
);

/**
 * POST /api/realtime/stream/:streamId/stop
 * Stop a processing stream
 */
router.post('/stream/:streamId/stop',
  asyncHandler(async (req, res) => {
    const { streamId } = req.params;

    try {
      logger.info(`Stopping stream: ${streamId}`);

      const result = await realtimeService.stopStreamProcessing(streamId);

      res.json({
        success: true,
        data: result,
        metadata: {
          timestamp: new Date().toISOString()
        }
      });

    } catch (error) {
      throw error;
    }
  })
);

/**
 * GET /api/realtime/stream/:streamId/status
 * Get stream status
 */
router.get('/stream/:streamId/status',
  asyncHandler(async (req, res) => {
    const { streamId } = req.params;

    try {
      const status = realtimeService.getStreamStatus(streamId);

      res.json({
        success: true,
        data: status,
        metadata: {
          timestamp: new Date().toISOString()
        }
      });

    } catch (error) {
      throw error;
    }
  })
);

/**
 * GET /api/realtime/streams
 * Get all active streams
 */
router.get('/streams',
  asyncHandler(async (req, res) => {
    try {
      const streams = realtimeService.getActiveStreams();

      res.json({
        success: true,
        data: streams,
        metadata: {
          timestamp: new Date().toISOString()
        }
      });

    } catch (error) {
      throw error;
    }
  })
);

/**
 * POST /api/realtime/text/analyze
 * Analyze text content
 */
router.post('/text/analyze',
  [
    body('text').notEmpty().isLength({ min: 1, max: 10000 }),
    body('includeEntities').optional().isBoolean(),
    body('includeSentiment').optional().isBoolean(),
    body('includeKeywords').optional().isBoolean(),
    body('language').optional().isString()
  ],
  asyncHandler(async (req, res) => {
    // Validate request
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      throw new ValidationError('Validation failed', errors.array());
    }

    const {
      text,
      includeEntities = true,
      includeSentiment = true,
      includeKeywords = true,
      language = 'auto'
    } = req.body;

    try {
      logger.info(`Analyzing text content`);

      const result = await realtimeService.processText(text, {
        operation: 'text_analysis',
        includeEntities: includeEntities === 'true' || includeEntities === true,
        includeSentiment: includeSentiment === 'true' || includeSentiment === true,
        includeKeywords: includeKeywords === 'true' || includeKeywords === true,
        language
      });

      res.json({
        success: true,
        data: result,
        metadata: {
          textLength: text.length,
          timestamp: new Date().toISOString()
        }
      });

    } catch (error) {
      throw error;
    }
  })
);

/**
 * POST /api/realtime/text/summarize
 * Summarize text content
 */
router.post('/text/summarize',
  [
    body('text').notEmpty().isLength({ min: 100, max: 10000 }),
    body('maxSentences').optional().isInt({ min: 1, max: 10 }),
    body('style').optional().isIn(['extractive', 'abstractive'])
  ],
  asyncHandler(async (req, res) => {
    // Validate request
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      throw new ValidationError('Validation failed', errors.array());
    }

    const {
      text,
      maxSentences = 3,
      style = 'extractive'
    } = req.body;

    try {
      logger.info(`Summarizing text content`);

      const result = await realtimeService.processText(text, {
        operation: 'summarization',
        maxSentences: parseInt(maxSentences),
        style
      });

      res.json({
        success: true,
        data: result,
        metadata: {
          originalLength: text.length,
          timestamp: new Date().toISOString()
        }
      });

    } catch (error) {
      throw error;
    }
  })
);

/**
 * POST /api/realtime/text/translate
 * Translate text content
 */
router.post('/text/translate',
  [
    body('text').notEmpty().isLength({ min: 1, max: 5000 }),
    body('targetLanguage').notEmpty().isString(),
    body('sourceLanguage').optional().isString()
  ],
  asyncHandler(async (req, res) => {
    // Validate request
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      throw new ValidationError('Validation failed', errors.array());
    }

    const {
      text,
      targetLanguage,
      sourceLanguage = 'auto'
    } = req.body;

    try {
      logger.info(`Translating text content`);

      const result = await realtimeService.processText(text, {
        operation: 'translation',
        targetLanguage,
        sourceLanguage
      });

      res.json({
        success: true,
        data: result,
        metadata: {
          originalLength: text.length,
          timestamp: new Date().toISOString()
        }
      });

    } catch (error) {
      throw error;
    }
  })
);

/**
 * POST /api/realtime/data/analyze
 * Analyze structured data
 */
router.post('/data/analyze',
  [
    body('data').notEmpty(),
    body('includeStatistics').optional().isBoolean(),
    body('includePatterns').optional().isBoolean(),
    body('includeAnomalies').optional().isBoolean()
  ],
  asyncHandler(async (req, res) => {
    // Validate request
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      throw new ValidationError('Validation failed', errors.array());
    }

    const {
      data,
      includeStatistics = true,
      includePatterns = true,
      includeAnomalies = false
    } = req.body;

    try {
      logger.info(`Analyzing structured data`);

      const result = await realtimeService.processData(data, {
        operation: 'data_processing',
        includeStatistics: includeStatistics === 'true' || includeStatistics === true,
        includePatterns: includePatterns === 'true' || includePatterns === true,
        includeAnomalies: includeAnomalies === 'true' || includeAnomalies === true
      });

      res.json({
        success: true,
        data: result,
        metadata: {
          dataSize: JSON.stringify(data).length,
          timestamp: new Date().toISOString()
        }
      });

    } catch (error) {
      throw error;
    }
  })
);

/**
 * GET /api/realtime/operations
 * Get supported operations
 */
router.get('/operations',
  asyncHandler(async (req, res) => {
    const operations = realtimeService.getSupportedOperations();

    res.json({
      success: true,
      data: {
        operations,
        summary: {
          total: Object.keys(operations).length,
          categories: ['text_processing', 'data_processing', 'stream_processing']
        }
      },
      metadata: {
        timestamp: new Date().toISOString()
      }
    });
  })
);

/**
 * GET /api/realtime/status
 * Get service status and health
 */
router.get('/status',
  asyncHandler(async (req, res) => {
    const status = await realtimeService.healthCheck();

    res.json({
      success: true,
      data: status,
      metadata: {
        timestamp: new Date().toISOString()
      }
    });
  })
);

/**
 * POST /api/realtime/test
 * Test real-time processing functionality
 */
router.post('/test',
  [
    body('operation').optional().isIn(['text_analysis', 'data_processing'])
  ],
  asyncHandler(async (req, res) => {
    const { operation = 'text_analysis' } = req.body;

    try {
      let testResult;

      if (operation === 'text_analysis') {
        testResult = await realtimeService.processText('This is a test message for the real-time processing service.', {
          operation: 'text_analysis'
        });
      } else {
        testResult = await realtimeService.processData({ test: true, numbers: [1, 2, 3, 4, 5] }, {
          operation: 'data_processing'
        });
      }

      res.json({
        success: true,
        data: {
          operation,
          test: 'Real-time processing test completed',
          status: 'available',
          result: testResult
        },
        metadata: {
          timestamp: new Date().toISOString()
        }
      });

    } catch (error) {
      throw error;
    }
  })
);

module.exports = router;

