const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs-extra');
const { body, validationResult } = require('express-validator');

const ocrService = require('../services/ocrService');
const config = require('../config/config');
const logger = require('../utils/logger');
const FileUtils = require('../utils/fileUtils');
const { asyncHandler, ValidationError } = require('../middleware/errorHandler');

const router = express.Router();

// Configure multer for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, config.upload.tempDir);
  },
  filename: (req, file, cb) => {
    const uniqueName = FileUtils.generateUniqueFilename(file.originalname);
    cb(null, uniqueName);
  }
});

const upload = multer({
  storage,
  limits: {
    fileSize: 50 * 1024 * 1024, // 50MB
    files: 10
  },
  fileFilter: (req, file, cb) => {
    const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp', 'image/bmp', 'image/tiff', 'application/pdf'];
    
    if (allowedTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error(`Unsupported file type: ${file.mimetype}`), false);
    }
  }
});

/**
 * POST /api/ocr/image
 * Extract text from uploaded image
 */
router.post('/image', 
  upload.single('image'),
  [
    body('engine').optional().isIn(['tesseract', 'easyocr', 'paddleocr']),
    body('languages').optional().isString(),
    body('confidence').optional().isFloat({ min: 0, max: 1 })
  ],
  asyncHandler(async (req, res) => {
    // Validate request
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      throw new ValidationError('Validation failed', errors.array());
    }

    if (!req.file) {
      throw new ValidationError('No image file provided');
    }

    const {
      engine = config.ocr.defaultEngine,
      languages = config.ocr.languages.join(','),
      confidence = 0.5
    } = req.body;

    try {
      logger.info(`Processing image OCR request: ${req.file.originalname}`);

      // Parse languages
      const languageArray = languages.split(',').map(lang => lang.trim());

      // Process image
      const result = await ocrService.extractTextFromImage(req.file.path, {
        engine,
        languages: languageArray,
        confidence: parseFloat(confidence)
      });

      // Clean up uploaded file
      await FileUtils.deleteFile(req.file.path);

      res.json({
        success: true,
        data: result,
        metadata: {
          filename: req.file.originalname,
          fileSize: req.file.size,
          mimeType: req.file.mimetype,
          timestamp: new Date().toISOString()
        }
      });

    } catch (error) {
      // Clean up uploaded file on error
      if (req.file && req.file.path) {
        await FileUtils.deleteFile(req.file.path);
      }
      throw error;
    }
  })
);

/**
 * POST /api/ocr/pdf
 * Extract text from uploaded PDF
 */
router.post('/pdf',
  upload.single('pdf'),
  [
    body('engine').optional().isIn(['tesseract', 'easyocr', 'paddleocr']),
    body('languages').optional().isString(),
    body('pageRange').optional().isString(),
    body('ocrMode').optional().isIn(['auto', 'text', 'ocr'])
  ],
  asyncHandler(async (req, res) => {
    // Validate request
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      throw new ValidationError('Validation failed', errors.array());
    }

    if (!req.file) {
      throw new ValidationError('No PDF file provided');
    }

    const {
      engine = config.ocr.defaultEngine,
      languages = config.ocr.languages.join(','),
      pageRange,
      ocrMode = 'auto'
    } = req.body;

    try {
      logger.info(`Processing PDF OCR request: ${req.file.originalname}`);

      // Parse languages
      const languageArray = languages.split(',').map(lang => lang.trim());

      // Parse page range if provided
      let parsedPageRange = null;
      if (pageRange) {
        const [start, end] = pageRange.split('-').map(num => parseInt(num.trim()));
        parsedPageRange = { start, end };
      }

      // Process PDF
      const result = await ocrService.extractTextFromPDF(req.file.path, {
        engine,
        languages: languageArray,
        pageRange: parsedPageRange,
        ocrMode
      });

      // Clean up uploaded file
      await FileUtils.deleteFile(req.file.path);

      res.json({
        success: true,
        data: result,
        metadata: {
          filename: req.file.originalname,
          fileSize: req.file.size,
          mimeType: req.file.mimetype,
          timestamp: new Date().toISOString()
        }
      });

    } catch (error) {
      // Clean up uploaded file on error
      if (req.file && req.file.path) {
        await FileUtils.deleteFile(req.file.path);
      }
      throw error;
    }
  })
);

/**
 * POST /api/ocr/batch
 * Process multiple files in batch
 */
router.post('/batch',
  upload.array('files', 10),
  [
    body('engine').optional().isIn(['tesseract', 'easyocr', 'paddleocr']),
    body('languages').optional().isString(),
    body('confidence').optional().isFloat({ min: 0, max: 1 })
  ],
  asyncHandler(async (req, res) => {
    // Validate request
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      throw new ValidationError('Validation failed', errors.array());
    }

    if (!req.files || req.files.length === 0) {
      throw new ValidationError('No files provided');
    }

    const {
      engine = config.ocr.defaultEngine,
      languages = config.ocr.languages.join(','),
      confidence = 0.5
    } = req.body;

    try {
      logger.info(`Processing batch OCR request: ${req.files.length} files`);

      // Parse languages
      const languageArray = languages.split(',').map(lang => lang.trim());

      // Prepare files for processing
      const files = req.files.map(file => ({
        filename: file.originalname,
        path: file.path,
        type: file.mimetype.startsWith('image/') ? 'image' : 'pdf'
      }));

      // Process batch
      const result = await ocrService.processBatch(files, {
        engine,
        languages: languageArray,
        confidence: parseFloat(confidence)
      });

      // Clean up uploaded files
      for (const file of req.files) {
        await FileUtils.deleteFile(file.path);
      }

      res.json({
        success: true,
        data: result,
        metadata: {
          totalFiles: req.files.length,
          timestamp: new Date().toISOString()
        }
      });

    } catch (error) {
      // Clean up uploaded files on error
      if (req.files) {
        for (const file of req.files) {
          await FileUtils.deleteFile(file.path);
        }
      }
      throw error;
    }
  })
);

/**
 * GET /api/ocr/languages
 * Get supported languages for each OCR engine
 */
router.get('/languages', asyncHandler(async (req, res) => {
  const supportedLanguages = ocrService.getSupportedLanguages();
  
  res.json({
    success: true,
    data: supportedLanguages,
    metadata: {
      timestamp: new Date().toISOString()
    }
  });
}));

/**
 * GET /api/ocr/engines
 * Get available OCR engines and their status
 */
router.get('/engines', asyncHandler(async (req, res) => {
  const engineStatus = await ocrService.healthCheck();
  
  const engines = [
    {
      name: 'tesseract',
      description: 'Google Tesseract OCR Engine',
      available: engineStatus.tesseract,
      languages: ocrService.getSupportedLanguages().tesseract,
      features: ['Multi-language', 'Confidence scores', 'Bounding boxes']
    },
    {
      name: 'easyocr',
      description: 'EasyOCR - Ready-to-use OCR',
      available: engineStatus.easyocr,
      languages: ocrService.getSupportedLanguages().easyocr,
      features: ['80+ languages', 'High accuracy', 'GPU support']
    },
    {
      name: 'paddleocr',
      description: 'PaddleOCR - Multilingual OCR',
      available: engineStatus.paddleocr,
      languages: ocrService.getSupportedLanguages().paddleocr,
      features: ['Fast inference', 'Lightweight', 'Chinese optimized']
    }
  ];
  
  res.json({
    success: true,
    data: {
      engines,
      default: config.ocr.defaultEngine,
      summary: {
        total: engines.length,
        available: engines.filter(e => e.available).length
      }
    },
    metadata: {
      timestamp: new Date().toISOString()
    }
  });
}));

/**
 * POST /api/ocr/test
 * Test OCR functionality with a sample image
 */
router.post('/test', asyncHandler(async (req, res) => {
  const { engine = 'tesseract' } = req.body;
  
  try {
    // Create a simple test image with text
    const testImagePath = path.join(config.upload.tempDir, 'test_ocr.png');
    
    // For now, return a mock response
    // In a real implementation, you would create or use a test image
    
    res.json({
      success: true,
      data: {
        engine,
        test: 'OCR engine test completed',
        status: 'available',
        sampleText: 'This is a test of the OCR engine functionality.'
      },
      metadata: {
        timestamp: new Date().toISOString()
      }
    });
    
  } catch (error) {
    throw error;
  }
}));

module.exports = router;

