const logger = require('../utils/logger');

/**
 * Global error handling middleware
 */
const errorHandler = (error, req, res, next) => {
  // Log the error
  logger.logError(error, req);

  // Default error response
  let statusCode = 500;
  let message = 'Internal Server Error';
  let details = null;

  // Handle specific error types
  if (error.name === 'ValidationError') {
    statusCode = 400;
    message = 'Validation Error';
    details = error.details || error.message;
  } else if (error.name === 'MulterError') {
    statusCode = 400;
    message = 'File Upload Error';
    
    switch (error.code) {
      case 'LIMIT_FILE_SIZE':
        details = 'File size exceeds the maximum allowed limit';
        break;
      case 'LIMIT_FILE_COUNT':
        details = 'Too many files uploaded';
        break;
      case 'LIMIT_UNEXPECTED_FILE':
        details = 'Unexpected file field';
        break;
      default:
        details = error.message;
    }
  } else if (error.code === 'ENOENT') {
    statusCode = 404;
    message = 'File Not Found';
    details = 'The requested file could not be found';
  } else if (error.code === 'EACCES') {
    statusCode = 403;
    message = 'Permission Denied';
    details = 'Insufficient permissions to access the resource';
  } else if (error.code === 'ENOSPC') {
    statusCode = 507;
    message = 'Insufficient Storage';
    details = 'Not enough disk space available';
  } else if (error.name === 'TimeoutError') {
    statusCode = 408;
    message = 'Request Timeout';
    details = 'The request took too long to process';
  } else if (error.name === 'ModelError') {
    statusCode = 503;
    message = 'Model Processing Error';
    details = error.message;
  } else if (error.statusCode) {
    statusCode = error.statusCode;
    message = error.message;
    details = error.details;
  }

  // Prepare error response
  const errorResponse = {
    error: true,
    message,
    statusCode,
    timestamp: new Date().toISOString(),
    path: req.originalUrl,
    method: req.method
  };

  // Add details if available
  if (details) {
    errorResponse.details = details;
  }

  // Add stack trace in development mode
  if (process.env.NODE_ENV === 'development') {
    errorResponse.stack = error.stack;
  }

  // Add request ID if available
  if (req.id) {
    errorResponse.requestId = req.id;
  }

  // Send error response
  res.status(statusCode).json(errorResponse);
};

/**
 * 404 Not Found handler
 */
const notFoundHandler = (req, res) => {
  const errorResponse = {
    error: true,
    message: 'Endpoint Not Found',
    statusCode: 404,
    timestamp: new Date().toISOString(),
    path: req.originalUrl,
    method: req.method,
    details: `The endpoint ${req.method} ${req.originalUrl} does not exist`
  };

  logger.warn('404 Not Found', {
    method: req.method,
    url: req.originalUrl,
    ip: req.ip
  });

  res.status(404).json(errorResponse);
};

/**
 * Async error wrapper
 */
const asyncHandler = (fn) => {
  return (req, res, next) => {
    Promise.resolve(fn(req, res, next)).catch(next);
  };
};

/**
 * Custom error classes
 */
class ValidationError extends Error {
  constructor(message, details = null) {
    super(message);
    this.name = 'ValidationError';
    this.details = details;
  }
}

class ModelError extends Error {
  constructor(message, modelName = null) {
    super(message);
    this.name = 'ModelError';
    this.modelName = modelName;
  }
}

class TimeoutError extends Error {
  constructor(message = 'Operation timed out') {
    super(message);
    this.name = 'TimeoutError';
  }
}

class FileProcessingError extends Error {
  constructor(message, filename = null) {
    super(message);
    this.name = 'FileProcessingError';
    this.filename = filename;
  }
}

module.exports = {
  errorHandler,
  notFoundHandler,
  asyncHandler,
  ValidationError,
  ModelError,
  TimeoutError,
  FileProcessingError
};

