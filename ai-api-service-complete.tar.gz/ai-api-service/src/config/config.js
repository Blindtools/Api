const path = require('path');

const config = {
  server: {
    port: process.env.PORT || 3000,
    host: process.env.HOST || '0.0.0.0',
    nodeEnv: process.env.NODE_ENV || 'development'
  },
  
  upload: {
    maxFileSize: process.env.MAX_FILE_SIZE || '50MB',
    tempDir: path.resolve(process.env.TEMP_DIR || './temp'),
    uploadDir: path.resolve(process.env.UPLOAD_DIR || './uploads'),
    supportedFormats: (process.env.SUPPORTED_FORMATS || 'jpg,jpeg,png,webp,bmp,tiff,pdf').split(',')
  },
  
  models: {
    cacheDir: path.resolve(process.env.MODEL_CACHE_DIR || './models'),
    pythonPath: process.env.PYTHON_PATH || 'python3',
    enableGpu: process.env.ENABLE_GPU === 'true',
    enableCaching: process.env.ENABLE_MODEL_CACHING !== 'false',
    cacheTtl: parseInt(process.env.MODEL_CACHE_TTL || '3600')
  },
  
  ocr: {
    defaultEngine: process.env.DEFAULT_OCR_ENGINE || 'easyocr',
    languages: (process.env.OCR_LANGUAGES || 'en').split(','),
    tesseractPath: process.env.TESSERACT_PATH || '/usr/bin/tesseract'
  },
  
  vision: {
    blipModelSize: process.env.BLIP_MODEL_SIZE || 'base',
    llavaModelSize: process.env.LLAVA_MODEL_SIZE || '7b',
    maxImageSize: parseInt(process.env.MAX_IMAGE_SIZE || '4096'),
    imageQuality: parseInt(process.env.IMAGE_QUALITY || '85')
  },
  
  api: {
    timeout: parseInt(process.env.API_TIMEOUT || '300000'),
    keyRequired: process.env.API_KEY_REQUIRED === 'true'
  },
  
  rateLimit: {
    windowMs: parseInt(process.env.RATE_LIMIT_WINDOW || '15') * 60 * 1000,
    maxRequests: parseInt(process.env.RATE_LIMIT_MAX_REQUESTS || '100')
  },
  
  cors: {
    origin: process.env.CORS_ORIGIN || '*'
  },
  
  logging: {
    level: process.env.LOG_LEVEL || 'info',
    file: path.resolve(process.env.LOG_FILE || './logs/app.log'),
    enableRequestLogging: process.env.ENABLE_REQUEST_LOGGING !== 'false'
  },
  
  security: {
    enableHelmet: process.env.ENABLE_HELMET !== 'false'
  },
  
  performance: {
    clusterMode: process.env.CLUSTER_MODE === 'true',
    maxWorkers: parseInt(process.env.MAX_WORKERS || '4'),
    memoryLimit: parseInt(process.env.MEMORY_LIMIT || '2048')
  },
  
  database: {
    url: process.env.DATABASE_URL || 'sqlite:./data/app.db',
    enableResultCaching: process.env.ENABLE_RESULT_CACHING !== 'false',
    cacheTtl: parseInt(process.env.CACHE_TTL || '1800')
  }
};

// Validation
if (!config.models.pythonPath) {
  throw new Error('PYTHON_PATH must be specified');
}

// Create directories if they don't exist
const fs = require('fs-extra');
const dirsToCreate = [
  config.upload.tempDir,
  config.upload.uploadDir,
  config.models.cacheDir,
  path.dirname(config.logging.file)
];

dirsToCreate.forEach(dir => {
  fs.ensureDirSync(dir);
});

module.exports = config;

