const fs = require('fs-extra');
const path = require('path');
const crypto = require('crypto');
const mime = require('mime-types');
const config = require('../config/config');
const logger = require('./logger');

class FileUtils {
  /**
   * Setup required directories
   */
  static setupDirectories() {
    const directories = [
      config.upload.tempDir,
      config.upload.uploadDir,
      config.models.cacheDir,
      path.dirname(config.logging.file),
      path.join(config.models.cacheDir, 'ocr'),
      path.join(config.models.cacheDir, 'vision'),
      path.join(config.models.cacheDir, 'nlp')
    ];

    directories.forEach(dir => {
      try {
        fs.ensureDirSync(dir);
        logger.debug(`Directory ensured: ${dir}`);
      } catch (error) {
        logger.error(`Failed to create directory ${dir}:`, error);
      }
    });
  }

  /**
   * Generate unique filename
   */
  static generateUniqueFilename(originalName, extension = null) {
    const timestamp = Date.now();
    const random = crypto.randomBytes(8).toString('hex');
    const ext = extension || path.extname(originalName);
    const baseName = path.basename(originalName, path.extname(originalName));
    
    return `${baseName}_${timestamp}_${random}${ext}`;
  }

  /**
   * Get file hash
   */
  static async getFileHash(filePath, algorithm = 'sha256') {
    try {
      const fileBuffer = await fs.readFile(filePath);
      const hash = crypto.createHash(algorithm);
      hash.update(fileBuffer);
      return hash.digest('hex');
    } catch (error) {
      logger.error(`Failed to generate hash for ${filePath}:`, error);
      throw error;
    }
  }

  /**
   * Validate file type
   */
  static validateFileType(filename, allowedTypes = null) {
    const allowedFormats = allowedTypes || config.upload.supportedFormats;
    const ext = path.extname(filename).toLowerCase().substring(1);
    
    return allowedFormats.includes(ext);
  }

  /**
   * Get file MIME type
   */
  static getMimeType(filename) {
    return mime.lookup(filename) || 'application/octet-stream';
  }

  /**
   * Get file size in bytes
   */
  static async getFileSize(filePath) {
    try {
      const stats = await fs.stat(filePath);
      return stats.size;
    } catch (error) {
      logger.error(`Failed to get file size for ${filePath}:`, error);
      return 0;
    }
  }

  /**
   * Clean up temporary files
   */
  static async cleanupTempFiles(maxAge = 3600000) { // 1 hour default
    try {
      const tempDir = config.upload.tempDir;
      const files = await fs.readdir(tempDir);
      const now = Date.now();

      for (const file of files) {
        const filePath = path.join(tempDir, file);
        const stats = await fs.stat(filePath);
        
        if (now - stats.mtime.getTime() > maxAge) {
          await fs.remove(filePath);
          logger.debug(`Cleaned up temp file: ${filePath}`);
        }
      }
    } catch (error) {
      logger.error('Failed to cleanup temp files:', error);
    }
  }

  /**
   * Save uploaded file
   */
  static async saveUploadedFile(file, customPath = null) {
    try {
      const filename = this.generateUniqueFilename(file.originalname);
      const filePath = customPath || path.join(config.upload.tempDir, filename);
      
      await fs.move(file.path, filePath);
      
      return {
        filename,
        path: filePath,
        originalName: file.originalname,
        size: file.size,
        mimeType: file.mimetype
      };
    } catch (error) {
      logger.error('Failed to save uploaded file:', error);
      throw error;
    }
  }

  /**
   * Create file metadata
   */
  static async createFileMetadata(filePath) {
    try {
      const stats = await fs.stat(filePath);
      const hash = await this.getFileHash(filePath);
      
      return {
        path: filePath,
        filename: path.basename(filePath),
        size: stats.size,
        mimeType: this.getMimeType(filePath),
        hash,
        created: stats.birthtime,
        modified: stats.mtime
      };
    } catch (error) {
      logger.error(`Failed to create metadata for ${filePath}:`, error);
      throw error;
    }
  }

  /**
   * Ensure file exists
   */
  static async ensureFileExists(filePath) {
    try {
      await fs.access(filePath, fs.constants.F_OK);
      return true;
    } catch (error) {
      return false;
    }
  }

  /**
   * Copy file with error handling
   */
  static async copyFile(source, destination) {
    try {
      await fs.ensureDir(path.dirname(destination));
      await fs.copy(source, destination);
      logger.debug(`File copied from ${source} to ${destination}`);
      return true;
    } catch (error) {
      logger.error(`Failed to copy file from ${source} to ${destination}:`, error);
      return false;
    }
  }

  /**
   * Delete file with error handling
   */
  static async deleteFile(filePath) {
    try {
      await fs.remove(filePath);
      logger.debug(`File deleted: ${filePath}`);
      return true;
    } catch (error) {
      logger.error(`Failed to delete file ${filePath}:`, error);
      return false;
    }
  }

  /**
   * Get directory size
   */
  static async getDirectorySize(dirPath) {
    try {
      let totalSize = 0;
      const files = await fs.readdir(dirPath);
      
      for (const file of files) {
        const filePath = path.join(dirPath, file);
        const stats = await fs.stat(filePath);
        
        if (stats.isDirectory()) {
          totalSize += await this.getDirectorySize(filePath);
        } else {
          totalSize += stats.size;
        }
      }
      
      return totalSize;
    } catch (error) {
      logger.error(`Failed to get directory size for ${dirPath}:`, error);
      return 0;
    }
  }

  /**
   * Format file size for human reading
   */
  static formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  }

  /**
   * Check available disk space
   */
  static async checkDiskSpace(directory = config.upload.tempDir) {
    try {
      const stats = await fs.stat(directory);
      // This is a simplified check - in production, you might want to use a library like 'check-disk-space'
      return {
        available: true,
        path: directory
      };
    } catch (error) {
      logger.error(`Failed to check disk space for ${directory}:`, error);
      return {
        available: false,
        path: directory
      };
    }
  }
}

// Schedule periodic cleanup of temp files
setInterval(() => {
  FileUtils.cleanupTempFiles();
}, 3600000); // Run every hour

module.exports = FileUtils;

