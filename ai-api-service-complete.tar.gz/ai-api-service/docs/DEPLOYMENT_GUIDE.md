# Deployment Guide

This guide covers various deployment options for the Advanced Open-Source AI API Service, from local development to production environments.

## Table of Contents

- [Prerequisites](#prerequisites)
- [Local Development](#local-development)
- [Render Deployment](#render-deployment)
- [Docker Deployment](#docker-deployment)
- [Traditional Server Deployment](#traditional-server-deployment)
- [Environment Configuration](#environment-configuration)
- [Performance Optimization](#performance-optimization)
- [Monitoring and Maintenance](#monitoring-and-maintenance)
- [Troubleshooting](#troubleshooting)

## Prerequisites

### System Requirements

**Minimum Requirements:**
- CPU: 2 cores
- RAM: 2GB
- Storage: 5GB free space
- Network: Internet connection for initial setup

**Recommended for Production:**
- CPU: 4+ cores
- RAM: 4GB+
- Storage: 20GB+ SSD
- Network: Stable internet connection

### Software Dependencies

**Required:**
- Node.js 18.0.0 or higher
- Python 3.8 or higher
- npm 8.0.0 or higher

**System Packages (Ubuntu/Debian):**
```bash
sudo apt-get update
sudo apt-get install -y \
  tesseract-ocr \
  tesseract-ocr-eng \
  tesseract-ocr-spa \
  tesseract-ocr-fra \
  tesseract-ocr-deu \
  tesseract-ocr-chi-sim \
  libtesseract-dev \
  python3-pip \
  build-essential
```

**System Packages (CentOS/RHEL):**
```bash
sudo yum update
sudo yum install -y \
  tesseract \
  tesseract-langpack-eng \
  tesseract-langpack-spa \
  tesseract-langpack-fra \
  tesseract-devel \
  python3-pip \
  gcc-c++ \
  make
```

## Local Development

### Quick Setup

1. **Clone and Install:**
```bash
git clone <repository-url>
cd ai-api-service
npm install
pip3 install -r requirements.txt
```

2. **Configure Environment:**
```bash
cp .env.example .env
# Edit .env with your preferences
```

3. **Start Development Server:**
```bash
npm run dev
# or
npm start
```

4. **Verify Installation:**
```bash
curl http://localhost:3000/api/health
```

### Development Configuration

**Environment Variables for Development:**
```env
NODE_ENV=development
PORT=3000
HOST=0.0.0.0
LOG_LEVEL=debug
ENABLE_REQUEST_LOGGING=true
```

**Hot Reload Setup:**
```bash
npm install -g nodemon
npm run dev
```

## Render Deployment

Render provides an excellent platform for deploying Node.js applications with automatic builds and deployments.

### Step-by-Step Render Deployment

1. **Prepare Repository:**
   - Ensure your code is in a Git repository
   - Include `render.yaml` configuration file
   - Verify `package.json` scripts are correct

2. **Connect to Render:**
   - Sign up at [render.com](https://render.com)
   - Connect your GitHub/GitLab repository
   - Select "Web Service" deployment type

3. **Configure Build Settings:**
   - **Build Command:** `npm install && pip3 install -r requirements.txt`
   - **Start Command:** `npm start`
   - **Environment:** Node
   - **Plan:** Starter (can upgrade later)

4. **Set Environment Variables:**
```env
NODE_ENV=production
PYTHON_PATH=python3
MAX_FILE_SIZE=50MB
DEFAULT_OCR_ENGINE=tesseract
OCR_LANGUAGES=en,es,fr,de,zh
RATE_LIMIT_WINDOW=15
RATE_LIMIT_MAX_REQUESTS=100
LOG_LEVEL=info
CORS_ORIGIN=*
```

5. **Configure Health Check:**
   - **Health Check Path:** `/api/health`
   - **Health Check Timeout:** 30 seconds

6. **Deploy:**
   - Click "Create Web Service"
   - Monitor build logs
   - Test deployment once live

### Render Configuration File

The included `render.yaml` provides infrastructure-as-code:

```yaml
services:
  - type: web
    name: ai-api-service
    env: node
    plan: starter
    buildCommand: npm install && pip3 install -r requirements.txt
    startCommand: npm start
    healthCheckPath: /api/health
    envVars:
      - key: NODE_ENV
        value: production
      - key: HOST
        value: 0.0.0.0
    disk:
      name: ai-api-data
      mountPath: /opt/render/project/src/data
      sizeGB: 1
```

### Render-Specific Considerations

**Build Time Optimization:**
- Use `.nvmrc` to specify Node.js version
- Cache dependencies when possible
- Minimize Python package installations

**Runtime Optimization:**
- Enable persistent disk for model caching
- Configure appropriate memory limits
- Use environment variables for configuration

**Monitoring:**
- Enable Render's built-in monitoring
- Set up log aggregation
- Configure alerts for service health

## Docker Deployment

Docker provides consistent deployment across different environments.

### Building Docker Image

1. **Build Image:**
```bash
docker build -t ai-api-service .
```

2. **Run Container:**
```bash
docker run -d \
  --name ai-api \
  -p 3000:3000 \
  -e NODE_ENV=production \
  -e HOST=0.0.0.0 \
  -v $(pwd)/data:/app/data \
  ai-api-service
```

3. **Verify Deployment:**
```bash
curl http://localhost:3000/api/health
```

### Docker Compose Setup

Create `docker-compose.yml`:

```yaml
version: '3.8'

services:
  ai-api:
    build: .
    ports:
      - "3000:3000"
    environment:
      - NODE_ENV=production
      - HOST=0.0.0.0
      - PYTHON_PATH=python3
      - LOG_LEVEL=info
    volumes:
      - ./data:/app/data
      - ./logs:/app/logs
      - ./models:/app/models
    restart: unless-stopped
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:3000/api/health"]
      interval: 30s
      timeout: 10s
      retries: 3
      start_period: 40s

  nginx:
    image: nginx:alpine
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./nginx.conf:/etc/nginx/nginx.conf
      - ./ssl:/etc/nginx/ssl
    depends_on:
      - ai-api
    restart: unless-stopped
```

**Start with Docker Compose:**
```bash
docker-compose up -d
```

### Multi-Stage Docker Build

For production optimization:

```dockerfile
# Build stage
FROM node:18-slim AS builder

WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production

# Production stage
FROM node:18-slim AS production

# Install system dependencies
RUN apt-get update && apt-get install -y \
    python3 python3-pip tesseract-ocr \
    && rm -rf /var/lib/apt/lists/*

WORKDIR /app

# Copy built dependencies
COPY --from=builder /app/node_modules ./node_modules
COPY . .

# Install Python dependencies
RUN pip3 install --no-cache-dir -r requirements.txt

EXPOSE 3000
CMD ["npm", "start"]
```

## Traditional Server Deployment

For deployment on VPS, dedicated servers, or cloud instances.

### Ubuntu/Debian Server Setup

1. **Update System:**
```bash
sudo apt-get update && sudo apt-get upgrade -y
```

2. **Install Node.js:**
```bash
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs
```

3. **Install Python and Dependencies:**
```bash
sudo apt-get install -y python3 python3-pip tesseract-ocr
```

4. **Create Application User:**
```bash
sudo useradd -m -s /bin/bash aiapi
sudo usermod -aG sudo aiapi
```

5. **Deploy Application:**
```bash
sudo -u aiapi git clone <repository-url> /home/aiapi/ai-api-service
cd /home/aiapi/ai-api-service
sudo -u aiapi npm install
sudo -u aiapi pip3 install -r requirements.txt
```

6. **Configure Environment:**
```bash
sudo -u aiapi cp .env.example .env
sudo -u aiapi nano .env
```

### Process Management with PM2

1. **Install PM2:**
```bash
sudo npm install -g pm2
```

2. **Create PM2 Configuration:**
```javascript
// ecosystem.config.js
module.exports = {
  apps: [{
    name: 'ai-api-service',
    script: 'server.js',
    instances: 'max',
    exec_mode: 'cluster',
    env: {
      NODE_ENV: 'development'
    },
    env_production: {
      NODE_ENV: 'production',
      PORT: 3000,
      HOST: '0.0.0.0'
    },
    log_file: './logs/combined.log',
    out_file: './logs/out.log',
    error_file: './logs/error.log',
    log_date_format: 'YYYY-MM-DD HH:mm:ss Z',
    max_memory_restart: '2G',
    node_args: '--max-old-space-size=2048'
  }]
};
```

3. **Start with PM2:**
```bash
pm2 start ecosystem.config.js --env production
pm2 save
pm2 startup
```

### Nginx Reverse Proxy

1. **Install Nginx:**
```bash
sudo apt-get install -y nginx
```

2. **Configure Nginx:**
```nginx
# /etc/nginx/sites-available/ai-api-service
server {
    listen 80;
    server_name your-domain.com;

    client_max_body_size 50M;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
        proxy_read_timeout 300s;
        proxy_connect_timeout 75s;
    }

    location /api/health {
        proxy_pass http://localhost:3000/api/health;
        access_log off;
    }
}
```

3. **Enable Site:**
```bash
sudo ln -s /etc/nginx/sites-available/ai-api-service /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx
```

### SSL Configuration with Let's Encrypt

1. **Install Certbot:**
```bash
sudo apt-get install -y certbot python3-certbot-nginx
```

2. **Obtain Certificate:**
```bash
sudo certbot --nginx -d your-domain.com
```

3. **Auto-renewal:**
```bash
sudo crontab -e
# Add: 0 12 * * * /usr/bin/certbot renew --quiet
```

## Environment Configuration

### Production Environment Variables

```env
# Server Configuration
NODE_ENV=production
PORT=3000
HOST=0.0.0.0

# Security
CORS_ORIGIN=https://your-domain.com
ENABLE_HELMET=true
API_KEY_REQUIRED=false

# Performance
CLUSTER_MODE=true
MAX_WORKERS=4
MEMORY_LIMIT=2048

# File Handling
MAX_FILE_SIZE=50MB
TEMP_DIR=/tmp/ai-api
MODEL_CACHE_DIR=/var/cache/ai-api/models

# Logging
LOG_LEVEL=info
LOG_FILE=/var/log/ai-api/app.log
ENABLE_REQUEST_LOGGING=true

# Rate Limiting
RATE_LIMIT_WINDOW=15
RATE_LIMIT_MAX_REQUESTS=100

# OCR Configuration
DEFAULT_OCR_ENGINE=tesseract
OCR_LANGUAGES=en,es,fr,de,zh
TESSERACT_PATH=/usr/bin/tesseract

# Python Configuration
PYTHON_PATH=/usr/bin/python3
```

### Security Configuration

**API Key Authentication (Optional):**
```env
API_KEY_REQUIRED=true
API_KEYS=key1,key2,key3
```

**CORS Configuration:**
```env
CORS_ORIGIN=https://your-frontend.com,https://your-app.com
```

**Rate Limiting:**
```env
RATE_LIMIT_WINDOW=15
RATE_LIMIT_MAX_REQUESTS=100
RATE_LIMIT_SKIP_SUCCESSFUL_REQUESTS=false
```

## Performance Optimization

### Node.js Optimization

**Memory Management:**
```bash
node --max-old-space-size=2048 server.js
```

**Cluster Mode:**
```env
CLUSTER_MODE=true
MAX_WORKERS=4
```

**Garbage Collection:**
```bash
node --expose-gc --optimize-for-size server.js
```

### System Optimization

**File Descriptor Limits:**
```bash
# /etc/security/limits.conf
aiapi soft nofile 65536
aiapi hard nofile 65536
```

**Kernel Parameters:**
```bash
# /etc/sysctl.conf
net.core.somaxconn = 65536
net.ipv4.tcp_max_syn_backlog = 65536
```

### Caching Strategy

**Model Caching:**
```env
ENABLE_MODEL_CACHING=true
MODEL_CACHE_TTL=3600
```

**Result Caching:**
```env
ENABLE_RESULT_CACHING=true
CACHE_TTL=1800
```

**File System Caching:**
- Use SSD storage for better I/O performance
- Configure appropriate temp directory cleanup
- Implement model preloading for frequently used models

## Monitoring and Maintenance

### Health Monitoring

**Built-in Health Checks:**
- `/api/health` - Basic health status
- `/api/health/detailed` - Comprehensive system info
- `/api/health/services` - Individual service status

**External Monitoring:**
```bash
# Simple uptime monitoring
*/5 * * * * curl -f http://localhost:3000/api/health || echo "Service down"
```

### Log Management

**Log Rotation:**
```bash
# /etc/logrotate.d/ai-api-service
/var/log/ai-api/*.log {
    daily
    missingok
    rotate 30
    compress
    delaycompress
    notifempty
    create 644 aiapi aiapi
    postrotate
        pm2 reload ai-api-service
    endscript
}
```

**Centralized Logging:**
- Configure log aggregation (ELK stack, Fluentd)
- Set up log analysis and alerting
- Monitor error rates and performance metrics

### Performance Monitoring

**System Metrics:**
- CPU usage and load average
- Memory consumption
- Disk I/O and space usage
- Network traffic

**Application Metrics:**
- Request rate and response times
- Error rates by endpoint
- Model processing times
- Queue sizes and processing delays

### Backup and Recovery

**Data Backup:**
```bash
# Backup script
#!/bin/bash
DATE=$(date +%Y%m%d_%H%M%S)
tar -czf /backup/ai-api-$DATE.tar.gz \
  /home/aiapi/ai-api-service \
  /var/log/ai-api \
  /var/cache/ai-api
```

**Configuration Backup:**
- Environment variables
- Nginx configuration
- PM2 configuration
- SSL certificates

## Troubleshooting

### Common Issues

**Service Won't Start:**
```bash
# Check logs
pm2 logs ai-api-service
tail -f /var/log/ai-api/error.log

# Check dependencies
node --version
python3 --version
tesseract --version

# Check permissions
ls -la /home/aiapi/ai-api-service
```

**High Memory Usage:**
```bash
# Monitor memory
htop
pm2 monit

# Restart service
pm2 restart ai-api-service
```

**OCR Not Working:**
```bash
# Test Tesseract
tesseract --list-langs
which tesseract

# Check Python packages
pip3 list | grep -E "(pytesseract|Pillow|opencv)"
```

**Slow Performance:**
```bash
# Check system resources
iostat -x 1
vmstat 1
netstat -i

# Optimize configuration
# Increase worker processes
# Enable caching
# Optimize batch sizes
```

### Debug Mode

**Enable Debug Logging:**
```env
LOG_LEVEL=debug
NODE_ENV=development
```

**Performance Profiling:**
```bash
node --prof server.js
# Generate profile report
node --prof-process isolate-*.log > profile.txt
```

### Recovery Procedures

**Service Recovery:**
```bash
# Stop service
pm2 stop ai-api-service

# Clear cache
rm -rf /tmp/ai-api/*
rm -rf /var/cache/ai-api/models/*

# Restart service
pm2 start ai-api-service
```

**Database Recovery:**
```bash
# If using SQLite
rm -f /var/cache/ai-api/app.db
# Service will recreate on restart
```

This deployment guide provides comprehensive instructions for deploying the Advanced Open-Source AI API Service in various environments. Choose the deployment method that best fits your infrastructure and requirements.

