const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const rateLimit = require('express-rate-limit');
const { createServer } = require('http');
const { Server } = require('socket.io');
const path = require('path');
const fs = require('fs-extra');
require('dotenv').config();

// Import configurations and utilities
const config = require('./src/config/config');
const logger = require('./src/utils/logger');
const errorHandler = require('./src/middleware/errorHandler');
const { setupDirectories } = require('./src/utils/fileUtils');

// Import route handlers
const ocrRoutes = require('./src/controllers/ocrController');
const visionRoutes = require('./src/controllers/visionController');
const realtimeRoutes = require('./src/controllers/realtimeController');
const healthRoutes = require('./src/controllers/healthController');

// Initialize Express app
const app = express();
const server = createServer(app);
const io = new Server(server, {
  cors: {
    origin: config.cors.origin,
    methods: ['GET', 'POST']
  }
});

// Setup directories
setupDirectories();

// Security middleware
app.use(helmet({
  crossOriginEmbedderPolicy: false,
  contentSecurityPolicy: false
}));

// CORS configuration
app.use(cors({
  origin: config.cors.origin,
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With']
}));

// Rate limiting
const limiter = rateLimit({
  windowMs: config.rateLimit.windowMs,
  max: config.rateLimit.maxRequests,
  message: {
    error: 'Too many requests from this IP, please try again later.',
    retryAfter: config.rateLimit.windowMs / 1000
  },
  standardHeaders: true,
  legacyHeaders: false
});

app.use('/api/', limiter);

// Request parsing middleware
app.use(express.json({ limit: config.upload.maxFileSize }));
app.use(express.urlencoded({ extended: true, limit: config.upload.maxFileSize }));

// Logging middleware
if (config.logging.enableRequestLogging) {
  app.use(morgan('combined', {
    stream: {
      write: (message) => logger.info(message.trim())
    }
  }));
}

// Static files
app.use('/docs', express.static(path.join(__dirname, 'docs')));
app.use('/models', express.static(path.join(__dirname, 'models')));

// API Routes
app.use('/api/health', healthRoutes);
app.use('/api/ocr', ocrRoutes);
app.use('/api/vision', visionRoutes);
app.use('/api/realtime', realtimeRoutes);

// Root endpoint
app.get('/', (req, res) => {
  res.json({
    name: 'Advanced Open-Source AI API Service',
    version: '1.0.0',
    description: 'Comprehensive AI API with OCR, Image Description, and Real-time Processing',
    endpoints: {
      health: '/api/health',
      ocr: '/api/ocr',
      vision: '/api/vision',
      realtime: '/api/realtime'
    },
    documentation: '/docs',
    status: 'running'
  });
});

// WebSocket handling for real-time features
io.on('connection', (socket) => {
  logger.info(`Client connected: ${socket.id}`);
  
  socket.on('process-stream', async (data) => {
    try {
      // Handle real-time processing
      const result = await processStreamData(data);
      socket.emit('stream-result', result);
    } catch (error) {
      logger.error('Stream processing error:', error);
      socket.emit('stream-error', { error: error.message });
    }
  });
  
  socket.on('disconnect', () => {
    logger.info(`Client disconnected: ${socket.id}`);
  });
});

// Error handling middleware
app.use(errorHandler.errorHandler);

// 404 handler
app.use('*', (req, res) => {
  res.status(404).json({
    error: 'Endpoint not found',
    message: `The requested endpoint ${req.originalUrl} does not exist.`,
    availableEndpoints: [
      '/api/health',
      '/api/ocr',
      '/api/vision',
      '/api/realtime'
    ]
  });
});

// Graceful shutdown handling
process.on('SIGTERM', () => {
  logger.info('SIGTERM received, shutting down gracefully');
  server.close(() => {
    logger.info('Process terminated');
    process.exit(0);
  });
});

process.on('SIGINT', () => {
  logger.info('SIGINT received, shutting down gracefully');
  server.close(() => {
    logger.info('Process terminated');
    process.exit(0);
  });
});

// Unhandled promise rejection handler
process.on('unhandledRejection', (reason, promise) => {
  logger.error('Unhandled Rejection at:', promise, 'reason:', reason);
});

// Uncaught exception handler
process.on('uncaughtException', (error) => {
  logger.error('Uncaught Exception:', error);
  process.exit(1);
});

// Start server
const PORT = config.server.port;
const HOST = config.server.host;

server.listen(PORT, HOST, () => {
  logger.info(`🚀 AI API Service running on http://${HOST}:${PORT}`);
  logger.info(`📚 Documentation available at http://${HOST}:${PORT}/docs`);
  logger.info(`🔧 Environment: ${config.server.nodeEnv}`);
  logger.info(`💾 Models directory: ${config.models.cacheDir}`);
  logger.info(`📁 Temp directory: ${config.upload.tempDir}`);
});

// Helper function for stream processing
async function processStreamData(data) {
  // This will be implemented in the realtime service
  return { processed: true, timestamp: Date.now() };
}

module.exports = { app, server, io };

