#!/usr/bin/env python3
"""
Tesseract OCR processing script
"""

import sys
import json
import os
from PIL import Image
import pytesseract
import cv2
import numpy as np

def preprocess_image(image_path):
    """Preprocess image for better OCR results"""
    try:
        # Read image
        image = cv2.imread(image_path)
        if image is None:
            raise ValueError(f"Could not read image: {image_path}")
        
        # Convert to grayscale
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        
        # Apply denoising
        denoised = cv2.fastNlMeansDenoising(gray)
        
        # Apply threshold to get binary image
        _, thresh = cv2.threshold(denoised, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        
        return thresh
    except Exception as e:
        # If preprocessing fails, try with original image
        return cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)

def extract_text_with_tesseract(image_path, languages='eng'):
    """Extract text using Tesseract OCR"""
    try:
        # Preprocess image
        processed_image = preprocess_image(image_path)
        
        # Configure Tesseract
        config = '--oem 3 --psm 6'  # Use LSTM OCR Engine Mode with uniform text block
        
        # Extract text with confidence scores
        data = pytesseract.image_to_data(
            processed_image, 
            lang=languages, 
            config=config, 
            output_type=pytesseract.Output.DICT
        )
        
        # Extract text
        text = pytesseract.image_to_string(
            processed_image, 
            lang=languages, 
            config=config
        ).strip()
        
        # Process bounding boxes and confidence scores
        bounding_boxes = []
        confidences = []
        
        for i in range(len(data['text'])):
            if int(data['conf'][i]) > 0:  # Only include confident detections
                word_text = data['text'][i].strip()
                if word_text:  # Only include non-empty text
                    bounding_boxes.append({
                        'text': word_text,
                        'confidence': float(data['conf'][i]) / 100.0,
                        'bbox': {
                            'x': int(data['left'][i]),
                            'y': int(data['top'][i]),
                            'width': int(data['width'][i]),
                            'height': int(data['height'][i])
                        }
                    })
                    confidences.append(float(data['conf'][i]) / 100.0)
        
        # Calculate average confidence
        avg_confidence = sum(confidences) / len(confidences) if confidences else 0.0
        
        # Detect languages (basic detection based on character sets)
        detected_languages = detect_languages(text)
        
        return {
            'text': text,
            'confidence': avg_confidence,
            'boundingBoxes': bounding_boxes,
            'detectedLanguages': detected_languages,
            'wordCount': len([box for box in bounding_boxes if box['text'].strip()]),
            'engine': 'tesseract'
        }
        
    except Exception as e:
        raise Exception(f"Tesseract OCR failed: {str(e)}")

def detect_languages(text):
    """Basic language detection based on character sets"""
    detected = []
    
    # Check for different character sets
    if any('\u4e00' <= char <= '\u9fff' for char in text):
        detected.append('chinese')
    if any('\u3040' <= char <= '\u309f' or '\u30a0' <= char <= '\u30ff' for char in text):
        detected.append('japanese')
    if any('\uac00' <= char <= '\ud7af' for char in text):
        detected.append('korean')
    if any('\u0600' <= char <= '\u06ff' for char in text):
        detected.append('arabic')
    if any('\u0400' <= char <= '\u04ff' for char in text):
        detected.append('cyrillic')
    
    # Default to English/Latin if no specific script detected
    if not detected and any(char.isalpha() for char in text):
        detected.append('latin')
    
    return detected

def main():
    if len(sys.argv) < 3:
        print(json.dumps({
            'error': 'Usage: python tesseract_ocr.py <image_path> <languages>'
        }))
        sys.exit(1)
    
    image_path = sys.argv[1]
    languages = sys.argv[2] if len(sys.argv) > 2 else 'eng'
    
    try:
        # Validate input file
        if not os.path.exists(image_path):
            raise FileNotFoundError(f"Image file not found: {image_path}")
        
        # Check if file is a valid image
        try:
            with Image.open(image_path) as img:
                img.verify()
        except Exception:
            raise ValueError(f"Invalid image file: {image_path}")
        
        # Extract text
        result = extract_text_with_tesseract(image_path, languages)
        
        # Output result as JSON
        print(json.dumps(result, ensure_ascii=False, indent=2))
        
    except Exception as e:
        error_result = {
            'error': str(e),
            'engine': 'tesseract',
            'text': '',
            'confidence': 0.0,
            'boundingBoxes': [],
            'detectedLanguages': []
        }
        print(json.dumps(error_result, ensure_ascii=False))
        sys.exit(1)

if __name__ == '__main__':
    main()

