#!/usr/bin/env python3
"""
BLIP Image Description Script
Uses a simple local implementation for image captioning without requiring API keys
"""

import sys
import json
import os
from PIL import Image
import base64
import io

def analyze_image_basic(image_path):
    """Basic image analysis without external models"""
    try:
        with Image.open(image_path) as img:
            # Get basic image properties
            width, height = img.size
            mode = img.mode
            format_name = img.format
            
            # Calculate aspect ratio
            aspect_ratio = width / height
            
            # Determine orientation
            if aspect_ratio > 1.3:
                orientation = "landscape"
            elif aspect_ratio < 0.7:
                orientation = "portrait"
            else:
                orientation = "square"
            
            # Analyze colors (simplified)
            if mode == 'RGB':
                # Get dominant colors by sampling
                img_small = img.resize((50, 50))
                colors = img_small.getcolors(maxcolors=256)
                if colors:
                    # Sort by frequency
                    colors.sort(key=lambda x: x[0], reverse=True)
                    dominant_color = colors[0][1]
                    
                    # Classify color
                    r, g, b = dominant_color
                    if r > 200 and g > 200 and b > 200:
                        color_desc = "bright"
                    elif r < 50 and g < 50 and b < 50:
                        color_desc = "dark"
                    elif r > g and r > b:
                        color_desc = "reddish"
                    elif g > r and g > b:
                        color_desc = "greenish"
                    elif b > r and b > g:
                        color_desc = "bluish"
                    else:
                        color_desc = "neutral"
                else:
                    color_desc = "colorful"
            else:
                color_desc = "monochrome" if mode == 'L' else "varied"
            
            # Generate description based on analysis
            size_desc = "large" if width > 1000 or height > 1000 else "medium" if width > 500 or height > 500 else "small"
            
            descriptions = [
                f"A {size_desc} {orientation} image with {color_desc} tones",
                f"An image measuring {width}x{height} pixels in {orientation} format",
                f"A {color_desc} {orientation} photograph or illustration",
                f"A {size_desc} digital image with {color_desc} coloring"
            ]
            
            # Select description based on detail level
            return {
                'description': descriptions[0],
                'alternative_descriptions': descriptions[1:],
                'confidence': 0.7,
                'details': {
                    'dimensions': f"{width}x{height}",
                    'orientation': orientation,
                    'color_tone': color_desc,
                    'size_category': size_desc,
                    'format': format_name,
                    'mode': mode
                },
                'modelVersion': 'basic_analyzer_v1.0'
            }
            
    except Exception as e:
        raise Exception(f"Image analysis failed: {str(e)}")

def generate_contextual_description(image_path, options):
    """Generate more contextual descriptions based on options"""
    basic_analysis = analyze_image_basic(image_path)
    
    detail_level = options.get('detail', 'medium')
    max_length = options.get('maxLength', 200)
    
    # Base description
    base_desc = basic_analysis['description']
    details = basic_analysis['details']
    
    if detail_level == 'low':
        description = f"An image showing visual content."
    elif detail_level == 'high':
        description = f"{base_desc}. The image appears to be a {details['format']} file with {details['mode']} color mode, featuring {details['color_tone']} tones in a {details['orientation']} composition. The dimensions are {details['dimensions']} pixels, making it a {details['size_category']}-sized image suitable for various display purposes."
    else:  # medium
        description = f"{base_desc}. This {details['orientation']} image features {details['color_tone']} tones and appears to be well-composed for viewing."
    
    # Truncate if necessary
    if len(description) > max_length:
        description = description[:max_length-3] + "..."
    
    return {
        'description': description,
        'confidence': basic_analysis['confidence'],
        'details': basic_analysis['details'],
        'modelVersion': basic_analysis['modelVersion']
    }

def main():
    if len(sys.argv) < 2:
        print(json.dumps({
            'error': 'Usage: python blip_description.py <image_path> [options_json]'
        }))
        sys.exit(1)
    
    image_path = sys.argv[1]
    options = {}
    
    if len(sys.argv) > 2:
        try:
            options = json.loads(sys.argv[2])
        except json.JSONDecodeError:
            options = {}
    
    try:
        # Validate input file
        if not os.path.exists(image_path):
            raise FileNotFoundError(f"Image file not found: {image_path}")
        
        # Check if file is a valid image
        try:
            with Image.open(image_path) as img:
                img.verify()
        except Exception:
            raise ValueError(f"Invalid image file: {image_path}")
        
        # Generate description
        result = generate_contextual_description(image_path, options)
        
        # Output result as JSON
        print(json.dumps(result, ensure_ascii=False, indent=2))
        
    except Exception as e:
        error_result = {
            'error': str(e),
            'description': 'Unable to process image',
            'confidence': 0.0,
            'details': {},
            'modelVersion': 'basic_analyzer_v1.0'
        }
        print(json.dumps(error_result, ensure_ascii=False))
        sys.exit(1)

if __name__ == '__main__':
    main()

