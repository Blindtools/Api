#!/usr/bin/env python3
"""
Comprehensive Image Analysis Script
Provides detailed analysis of images including objects, scenes, colors, and composition
"""

import sys
import json
import os
from PIL import Image, ImageStat
import colorsys
import numpy as np

def analyze_colors(image_path):
    """Analyze color composition of the image"""
    try:
        with Image.open(image_path) as img:
            # Convert to RGB if necessary
            if img.mode != 'RGB':
                img = img.convert('RGB')
            
            # Get color statistics
            stat = ImageStat.Stat(img)
            
            # Get dominant colors
            img_small = img.resize((50, 50))
            colors = img_small.getcolors(maxcolors=256)
            
            color_analysis = {
                'dominant_colors': [],
                'brightness': sum(stat.mean) / 3,
                'contrast': sum(stat.stddev) / 3,
                'color_palette': 'unknown'
            }
            
            if colors:
                # Sort by frequency and get top colors
                colors.sort(key=lambda x: x[0], reverse=True)
                top_colors = colors[:5]
                
                for count, (r, g, b) in top_colors:
                    # Convert to HSV for better color description
                    h, s, v = colorsys.rgb_to_hsv(r/255, g/255, b/255)
                    
                    # Determine color name
                    if s < 0.1:
                        color_name = "gray" if v < 0.9 else "white" if v > 0.9 else "black"
                    else:
                        hue_names = ["red", "orange", "yellow", "green", "cyan", "blue", "purple", "pink"]
                        hue_index = int(h * 8) % 8
                        color_name = hue_names[hue_index]
                    
                    color_analysis['dominant_colors'].append({
                        'color': color_name,
                        'rgb': [r, g, b],
                        'percentage': (count / (50 * 50)) * 100,
                        'saturation': s,
                        'brightness': v
                    })
                
                # Determine overall palette
                avg_saturation = sum(c['saturation'] for c in color_analysis['dominant_colors']) / len(color_analysis['dominant_colors'])
                if avg_saturation > 0.7:
                    color_analysis['color_palette'] = 'vibrant'
                elif avg_saturation > 0.3:
                    color_analysis['color_palette'] = 'moderate'
                else:
                    color_analysis['color_palette'] = 'muted'
            
            return color_analysis
            
    except Exception as e:
        return {'error': f"Color analysis failed: {str(e)}"}

def analyze_composition(image_path):
    """Analyze image composition and layout"""
    try:
        with Image.open(image_path) as img:
            width, height = img.size
            aspect_ratio = width / height
            
            # Determine composition type
            if aspect_ratio > 1.5:
                composition_type = "wide_landscape"
            elif aspect_ratio > 1.1:
                composition_type = "landscape"
            elif aspect_ratio < 0.7:
                composition_type = "portrait"
            elif aspect_ratio < 0.9:
                composition_type = "tall_portrait"
            else:
                composition_type = "square"
            
            # Analyze rule of thirds (simplified)
            # Divide image into 9 sections and analyze content distribution
            third_width = width // 3
            third_height = height // 3
            
            composition_analysis = {
                'aspect_ratio': round(aspect_ratio, 2),
                'composition_type': composition_type,
                'dimensions': {'width': width, 'height': height},
                'rule_of_thirds': {
                    'follows_rule': aspect_ratio > 0.8 and aspect_ratio < 1.2,  # Simplified check
                    'grid_sections': 9
                },
                'orientation': 'landscape' if aspect_ratio > 1 else 'portrait' if aspect_ratio < 1 else 'square'
            }
            
            return composition_analysis
            
    except Exception as e:
        return {'error': f"Composition analysis failed: {str(e)}"}

def detect_objects_basic(image_path):
    """Basic object detection based on image properties"""
    try:
        with Image.open(image_path) as img:
            width, height = img.size
            
            # Very basic "object detection" based on image characteristics
            objects = []
            
            # Analyze image complexity
            if img.mode == 'RGB':
                img_gray = img.convert('L')
                img_array = np.array(img_gray)
                
                # Calculate edge density (simplified edge detection)
                if img_array.std() > 50:  # High variation suggests complex content
                    objects.append({
                        'type': 'complex_scene',
                        'confidence': 0.7,
                        'description': 'Scene with multiple elements or detailed content'
                    })
                elif img_array.std() > 20:  # Medium variation
                    objects.append({
                        'type': 'simple_scene',
                        'confidence': 0.6,
                        'description': 'Scene with moderate detail'
                    })
                else:  # Low variation
                    objects.append({
                        'type': 'minimal_scene',
                        'confidence': 0.5,
                        'description': 'Simple or uniform content'
                    })
            
            # Guess content type based on aspect ratio and size
            aspect_ratio = width / height
            if aspect_ratio > 1.5 and width > 800:
                objects.append({
                    'type': 'landscape_photo',
                    'confidence': 0.6,
                    'description': 'Possibly a landscape or wide-angle photograph'
                })
            elif aspect_ratio < 0.8 and height > 600:
                objects.append({
                    'type': 'portrait_photo',
                    'confidence': 0.6,
                    'description': 'Possibly a portrait or vertical photograph'
                })
            
            return {
                'objects': objects,
                'object_count': len(objects),
                'detection_method': 'basic_heuristics'
            }
            
    except Exception as e:
        return {'error': f"Object detection failed: {str(e)}"}

def analyze_scene_context(image_path):
    """Analyze scene context and environment"""
    try:
        with Image.open(image_path) as img:
            width, height = img.size
            format_name = img.format
            
            # Basic scene analysis
            scene_analysis = {
                'scene_type': 'unknown',
                'environment': 'unknown',
                'lighting': 'unknown',
                'setting': 'unknown'
            }
            
            # Analyze brightness for lighting
            if img.mode == 'RGB':
                stat = ImageStat.Stat(img)
                avg_brightness = sum(stat.mean) / 3
                
                if avg_brightness > 200:
                    scene_analysis['lighting'] = 'bright'
                elif avg_brightness > 100:
                    scene_analysis['lighting'] = 'moderate'
                else:
                    scene_analysis['lighting'] = 'dim'
            
            # Guess environment based on image properties
            aspect_ratio = width / height
            if aspect_ratio > 1.3:
                scene_analysis['environment'] = 'outdoor_landscape'
                scene_analysis['scene_type'] = 'landscape'
            elif aspect_ratio < 0.8:
                scene_analysis['environment'] = 'indoor_portrait'
                scene_analysis['scene_type'] = 'portrait'
            else:
                scene_analysis['environment'] = 'general'
                scene_analysis['scene_type'] = 'general'
            
            # Determine setting based on format and size
            if format_name in ['JPEG', 'JPG'] and (width > 1000 or height > 1000):
                scene_analysis['setting'] = 'photograph'
            elif format_name == 'PNG':
                scene_analysis['setting'] = 'digital_graphic'
            else:
                scene_analysis['setting'] = 'image'
            
            return scene_analysis
            
    except Exception as e:
        return {'error': f"Scene analysis failed: {str(e)}"}

def comprehensive_analysis(image_path, options):
    """Perform comprehensive image analysis"""
    try:
        analysis_result = {
            'success': True,
            'analysis_type': 'comprehensive',
            'timestamp': None
        }
        
        # Perform different types of analysis based on options
        if options.get('includeColors', True):
            analysis_result['colors'] = analyze_colors(image_path)
        
        if options.get('includeComposition', True):
            analysis_result['composition'] = analyze_composition(image_path)
        
        if options.get('includeObjects', True):
            analysis_result['objects'] = detect_objects_basic(image_path)
        
        if options.get('includeScenes', True):
            analysis_result['scene'] = analyze_scene_context(image_path)
        
        # Generate summary
        summary_parts = []
        
        if 'composition' in analysis_result:
            comp = analysis_result['composition']
            summary_parts.append(f"A {comp['composition_type']} image with {comp['orientation']} orientation")
        
        if 'colors' in analysis_result and 'color_palette' in analysis_result['colors']:
            palette = analysis_result['colors']['color_palette']
            summary_parts.append(f"featuring a {palette} color palette")
        
        if 'scene' in analysis_result:
            scene = analysis_result['scene']
            if scene['lighting'] != 'unknown':
                summary_parts.append(f"with {scene['lighting']} lighting")
        
        analysis_result['summary'] = '. '.join(summary_parts) if summary_parts else "Image analysis completed"
        
        return analysis_result
        
    except Exception as e:
        return {
            'success': False,
            'error': str(e),
            'analysis_type': 'comprehensive'
        }

def main():
    if len(sys.argv) < 2:
        print(json.dumps({
            'error': 'Usage: python comprehensive_analysis.py <image_path> [options_json]'
        }))
        sys.exit(1)
    
    image_path = sys.argv[1]
    options = {}
    
    if len(sys.argv) > 2:
        try:
            options = json.loads(sys.argv[2])
        except json.JSONDecodeError:
            options = {}
    
    try:
        # Validate input file
        if not os.path.exists(image_path):
            raise FileNotFoundError(f"Image file not found: {image_path}")
        
        # Check if file is a valid image
        try:
            with Image.open(image_path) as img:
                img.verify()
        except Exception:
            raise ValueError(f"Invalid image file: {image_path}")
        
        # Perform comprehensive analysis
        result = comprehensive_analysis(image_path, options)
        
        # Output result as JSON
        print(json.dumps(result, ensure_ascii=False, indent=2))
        
    except Exception as e:
        error_result = {
            'success': False,
            'error': str(e),
            'analysis_type': 'comprehensive'
        }
        print(json.dumps(error_result, ensure_ascii=False))
        sys.exit(1)

if __name__ == '__main__':
    main()

