#!/usr/bin/env python3
"""
Text Analysis Script
Provides sentiment analysis, entity extraction, and keyword detection without external APIs
"""

import sys
import json
import re
from collections import Counter
import string

def detect_language(text):
    """Basic language detection based on character patterns"""
    # Simple heuristic-based language detection
    if re.search(r'[\u4e00-\u9fff]', text):
        return 'zh'
    elif re.search(r'[\u3040-\u309f\u30a0-\u30ff]', text):
        return 'ja'
    elif re.search(r'[\uac00-\ud7af]', text):
        return 'ko'
    elif re.search(r'[\u0600-\u06ff]', text):
        return 'ar'
    elif re.search(r'[\u0400-\u04ff]', text):
        return 'ru'
    else:
        return 'en'  # Default to English

def analyze_sentiment(text):
    """Basic sentiment analysis using word lists"""
    # Simple positive and negative word lists
    positive_words = {
        'good', 'great', 'excellent', 'amazing', 'wonderful', 'fantastic', 'awesome',
        'love', 'like', 'enjoy', 'happy', 'pleased', 'satisfied', 'perfect',
        'best', 'brilliant', 'outstanding', 'superb', 'magnificent', 'beautiful',
        'positive', 'success', 'win', 'victory', 'achievement', 'accomplish'
    }
    
    negative_words = {
        'bad', 'terrible', 'awful', 'horrible', 'disgusting', 'hate', 'dislike',
        'angry', 'sad', 'disappointed', 'frustrated', 'annoyed', 'upset',
        'worst', 'fail', 'failure', 'problem', 'issue', 'wrong', 'error',
        'negative', 'loss', 'defeat', 'disaster', 'crisis', 'trouble'
    }
    
    # Clean and tokenize text
    words = re.findall(r'\b\w+\b', text.lower())
    
    positive_count = sum(1 for word in words if word in positive_words)
    negative_count = sum(1 for word in words if word in negative_words)
    total_words = len(words)
    
    if total_words == 0:
        return {
            'sentiment': 'neutral',
            'confidence': 0.0,
            'positive_score': 0.0,
            'negative_score': 0.0
        }
    
    positive_score = positive_count / total_words
    negative_score = negative_count / total_words
    
    # Determine overall sentiment
    if positive_score > negative_score and positive_score > 0.05:
        sentiment = 'positive'
        confidence = min(positive_score * 2, 1.0)
    elif negative_score > positive_score and negative_score > 0.05:
        sentiment = 'negative'
        confidence = min(negative_score * 2, 1.0)
    else:
        sentiment = 'neutral'
        confidence = 1.0 - abs(positive_score - negative_score)
    
    return {
        'sentiment': sentiment,
        'confidence': confidence,
        'positive_score': positive_score,
        'negative_score': negative_score,
        'positive_words_found': positive_count,
        'negative_words_found': negative_count
    }

def extract_entities(text):
    """Basic named entity extraction using patterns"""
    entities = {
        'emails': [],
        'urls': [],
        'phone_numbers': [],
        'dates': [],
        'numbers': [],
        'capitalized_words': []
    }
    
    # Email pattern
    email_pattern = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
    entities['emails'] = re.findall(email_pattern, text)
    
    # URL pattern
    url_pattern = r'http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\\(\\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+'
    entities['urls'] = re.findall(url_pattern, text)
    
    # Phone number pattern (simple)
    phone_pattern = r'\b\d{3}[-.]?\d{3}[-.]?\d{4}\b'
    entities['phone_numbers'] = re.findall(phone_pattern, text)
    
    # Date pattern (simple)
    date_pattern = r'\b\d{1,2}[/-]\d{1,2}[/-]\d{2,4}\b|\b\d{4}[/-]\d{1,2}[/-]\d{1,2}\b'
    entities['dates'] = re.findall(date_pattern, text)
    
    # Numbers
    number_pattern = r'\b\d+(?:\.\d+)?\b'
    entities['numbers'] = re.findall(number_pattern, text)
    
    # Capitalized words (potential proper nouns)
    capitalized_pattern = r'\b[A-Z][a-z]+\b'
    capitalized_words = re.findall(capitalized_pattern, text)
    # Filter out common words
    common_words = {'The', 'This', 'That', 'These', 'Those', 'A', 'An', 'And', 'Or', 'But', 'If', 'When', 'Where', 'How', 'Why', 'What', 'Who'}
    entities['capitalized_words'] = [word for word in capitalized_words if word not in common_words]
    
    return entities

def extract_keywords(text, max_keywords=10):
    """Extract keywords using frequency analysis"""
    # Common stop words
    stop_words = {
        'the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of', 'with',
        'by', 'from', 'up', 'about', 'into', 'through', 'during', 'before', 'after',
        'above', 'below', 'between', 'among', 'is', 'are', 'was', 'were', 'be', 'been',
        'being', 'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would', 'could',
        'should', 'may', 'might', 'must', 'can', 'this', 'that', 'these', 'those',
        'i', 'you', 'he', 'she', 'it', 'we', 'they', 'me', 'him', 'her', 'us', 'them'
    }
    
    # Clean and tokenize text
    text_clean = re.sub(r'[^\w\s]', ' ', text.lower())
    words = [word for word in text_clean.split() if len(word) > 2 and word not in stop_words]
    
    # Count word frequencies
    word_freq = Counter(words)
    
    # Get top keywords
    keywords = []
    for word, freq in word_freq.most_common(max_keywords):
        keywords.append({
            'word': word,
            'frequency': freq,
            'score': freq / len(words) if words else 0
        })
    
    return keywords

def analyze_text_structure(text):
    """Analyze text structure and readability"""
    sentences = re.split(r'[.!?]+', text)
    sentences = [s.strip() for s in sentences if s.strip()]
    
    words = re.findall(r'\b\w+\b', text)
    paragraphs = [p.strip() for p in text.split('\n\n') if p.strip()]
    
    # Calculate averages
    avg_words_per_sentence = len(words) / len(sentences) if sentences else 0
    avg_sentences_per_paragraph = len(sentences) / len(paragraphs) if paragraphs else 0
    
    # Character analysis
    char_count = len(text)
    char_count_no_spaces = len(text.replace(' ', ''))
    
    return {
        'sentence_count': len(sentences),
        'word_count': len(words),
        'paragraph_count': len(paragraphs),
        'character_count': char_count,
        'character_count_no_spaces': char_count_no_spaces,
        'avg_words_per_sentence': round(avg_words_per_sentence, 2),
        'avg_sentences_per_paragraph': round(avg_sentences_per_paragraph, 2),
        'readability_score': min(100, max(0, 100 - (avg_words_per_sentence * 2)))  # Simple readability score
    }

def perform_text_analysis(text, options):
    """Perform comprehensive text analysis"""
    result = {
        'success': True,
        'analysis_type': 'comprehensive_text_analysis'
    }
    
    # Language detection
    detected_language = detect_language(text)
    result['language'] = {
        'detected': detected_language,
        'confidence': 0.8  # Mock confidence
    }
    
    # Sentiment analysis
    if options.get('includeSentiment', True):
        result['sentiment'] = analyze_sentiment(text)
    
    # Entity extraction
    if options.get('includeEntities', True):
        result['entities'] = extract_entities(text)
    
    # Keyword extraction
    if options.get('includeKeywords', True):
        result['keywords'] = extract_keywords(text)
    
    # Text structure analysis
    result['structure'] = analyze_text_structure(text)
    
    # Summary statistics
    result['summary'] = {
        'text_length': len(text),
        'word_count': len(re.findall(r'\b\w+\b', text)),
        'sentence_count': len(re.split(r'[.!?]+', text)),
        'language': detected_language,
        'sentiment': result.get('sentiment', {}).get('sentiment', 'unknown')
    }
    
    return result

def main():
    if len(sys.argv) < 2:
        print(json.dumps({
            'error': 'Usage: python text_analysis.py <text> [options_json]'
        }))
        sys.exit(1)
    
    text = sys.argv[1]
    options = {}
    
    if len(sys.argv) > 2:
        try:
            options = json.loads(sys.argv[2])
        except json.JSONDecodeError:
            options = {}
    
    try:
        # Validate input
        if not text or not text.strip():
            raise ValueError("Empty text provided")
        
        # Perform analysis
        result = perform_text_analysis(text, options)
        
        # Output result as JSON
        print(json.dumps(result, ensure_ascii=False, indent=2))
        
    except Exception as e:
        error_result = {
            'success': False,
            'error': str(e),
            'analysis_type': 'text_analysis'
        }
        print(json.dumps(error_result, ensure_ascii=False))
        sys.exit(1)

if __name__ == '__main__':
    main()

